package com.ust.training.util;

public interface Instrument {
public void play();
}
