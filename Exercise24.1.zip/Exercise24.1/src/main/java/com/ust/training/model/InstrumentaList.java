/*
 * InstrumentaList
 * InstrumentaList is a class which implements Performer
 * 12-10-2020
 */
package com.ust.training.model;

import com.ust.training.util.Performer;
/*
 * InstrumentaList is a class which implements Performer
 */
public class InstrumentaList implements Performer {

	Saxophone saxophone;
	
	
	/*
	 * getter method for saxophone
	 */
	public Saxophone getSaxophone() {
		return saxophone;
	}


	/*
	 * setter method for saxophone
	 */
	public void setSaxophone(Saxophone saxophone) {
		this.saxophone = saxophone;
	}

	/*
	 * implementation method
	 */

	public void perform() {
		this.saxophone.play();
		
	}

}
