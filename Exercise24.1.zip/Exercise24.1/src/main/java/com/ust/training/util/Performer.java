/*
 * Performer
 * Performer is an interface having a method perform.
 * 12-10-2020
 */

package com.ust.training.util;

/*
 * Performer is an interface having a method perform.
 */

public interface Performer {

	/*
	 * implementation method
	 */
	public void perform();
}
