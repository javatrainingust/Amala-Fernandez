package com.ust.model;

/**
 * SBAccount
 * SBAccount class includes SBaccount details
 * 30-09-2020
 */

import com.ust.util.ICalculator;
import com.ust.util.IntrestCalculation;

public class SBAccount extends Account {

	private float balance = 50000;
	
	
	public float getBalance() {
		return balance;
	}

	float duration = 1;
	IntrestCalculation interest = new IntrestCalculation();

	public SBAccount() {
		System.out.println("inside SBAccount default constructor");
	}

	public SBAccount(float balance, float duration) {
		super();
		this.balance = balance;
		this.duration = duration;
		System.out.println("inside SBAccount parameterised constructor");
	}

	/* withdrawMoney method for withdrawing money */

	public void withdrawMoney(float amountWithdrawn) {
		balance = balance - amountWithdrawn;
		System.out.println("Account balance after withdrawing is :" + balance);
	}

	/* interestCalculation method for calculating interest */

	public void interestCalculation(float amount, ICalculator interest) {

		float sbinterest = interest.calculateInterest(amount, duration);
		System.out.println("savings bank interest" + sbinterest);
	}
}
