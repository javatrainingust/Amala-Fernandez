package com.ust.model;

import static org.junit.Assert.*;

import org.junit.Test;
/**
 * 
 *  FDAccountTest 
 *  FDAccountTest class is for testing FDAccount class
 *  01-10-2020
 * */
public class FDAccountTest {
	
	/* calculateInterest method for  testAutoRenewal */
	@Test
	public void testAutoRenewal() {
		boolean expectedValue=true;
		FDAccount fdAccount=new FDAccount();
		fdAccount.autoRenewal(7);
		
		boolean actualValue=fdAccount.isAutoRenewal();
		assertEquals(expectedValue,actualValue);
	}

}
