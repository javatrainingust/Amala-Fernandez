/***
 * SBAccountService 
 * SBAccountService is  class for displaying details
 * 06-10-2020
 * */
package com.training.java.service;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.java.dao.SBAccountDao;
import com.training.java.dao.SBAccountDaoImpl;
import com.ust.java.model.FDAccount;
import com.ust.java.model.LoanAccount;
import com.ust.java.model.SBAccount;
/***
 * SBAccountService is  class for displaying details
 * */

@Service
public class SBAccountService {

	@Autowired
	private SBAccountDao sbAccountDaoImpl;
	
	public SBAccountService()
	
	{
		
	}
	/* 
	 * for dispalying all the SBAccounts
	 *  */
	
	
		public List<SBAccount> getAllSBAccounts() 
		{
		List sbAccountList=	sbAccountDaoImpl.getAllSBAccounts();
		/*
		 * Iterator<SBAccount> iterator = sbAccountList.iterator();
		 * while(iterator.hasNext()){ SBAccount sAccount=iterator.next();
		 * 
		 * System.out.println("Account No "+sAccount.getAccountNo());
		 * System.out.println("Account Holder Name"+sAccount.getAccountHolderName());
		 * System.out.println("Balancce "+sAccount.getBalance());
		 * System.out.println("Duration "+sAccount.getDuration()); }
		 */
			return sbAccountList;
		}
		/*
		 * for displaying particular SBAccount 
		 * */
		
		public SBAccount getSBAccountsByAccountNo(int accountNo)
		{
			SBAccount sAccount=sbAccountDaoImpl.getSBAccountsByAccountNo(accountNo);
			System.out.println("Account No "+sAccount.getAccountNo());
			System.out.println("Account Holder Name"+sAccount.getAccountHolderName());
			System.out.println("Balancce "+sAccount.getBalance());
			System.out.println("Duration "+sAccount.getDuration());
			
			return sAccount;
		}
		
		/* 
		 * for deleting particular SBAccount
		 *  */
		public void deleteSBAccount(int accountNo){
			sbAccountDaoImpl.deleteSBAccount(accountNo);
		}
		
		/*
		 *  for getting all accounts  sorted by names
		 *  */
		public List<SBAccount>	getAllSBAccountsSortedByNames(){
			
			
			List<SBAccount> sAccountList = sbAccountDaoImpl.getAllSBAccounts();
			
			//Collections.sort(sAccountList);
			/* 
			 * Creating stream and sorting */
			Stream<SBAccount> sbAccountStream = sAccountList.stream();
			
			Stream<SBAccount> sortedStream = sbAccountStream.sorted();
			
			List sortedSbAccountList = sortedStream.collect(Collectors.toList());
			
			
			
			Iterator<SBAccount> iterator = sortedSbAccountList.iterator();
			
			while(iterator.hasNext()){
				
				SBAccount sAccount = iterator.next();
				
				System.out.println("Account No "+sAccount.getAccountNo());
				System.out.println("Account Holder Name"+sAccount.getAccountHolderName());
				System.out.println("Balancce "+sAccount.getBalance());
				System.out.println("Duration "+sAccount.getDuration());
				
				}			
			
			
			
			return sAccountList;
			
			
			
	}
		
		/* 
		 * for getting all accounts  sorted by balance*/
		
public List<SBAccount>	getAllSBAccountsSortedByBalance(){
			
			
			List<SBAccount> sAccountList = sbAccountDaoImpl.getAllSBAccounts();
			
			//Collections.sort(sAccountList,new SBBalanceComparator());
			
			/* Creating stream and sorting */
			Stream<SBAccount> sbAccountStream = sAccountList.stream();
			
			Stream<SBAccount> sortedStream = sbAccountStream.sorted(new SBBalanceComparator());
			
			List sortedSbAccountList = sortedStream.collect(Collectors.toList());
			
			Iterator<SBAccount> iterator = sortedSbAccountList.iterator();
			
			while(iterator.hasNext()){
				
				SBAccount sAccount = iterator.next();
				
				System.out.println("Account No "+sAccount.getAccountNo());
				System.out.println("Account Holder Name"+sAccount.getAccountHolderName());
				System.out.println("Balancce "+sAccount.getBalance());
				System.out.println("Duration "+sAccount.getDuration());
				
				}			
			
			
			
			return sAccountList;
			
			
			
	}

/* 
 *  method is for adding  SB Accounts */

public boolean addSBAccounts(SBAccount sbAccount) 
{
	 boolean isAdded=sbAccountDaoImpl.addSBAccounts(sbAccount);
		
		if(!isAdded){
			System.out.println("current Account already exist");
			return false;
			
		}
		else{
		System.out.println("current Account successfully added");
		return true;
	}	
}

/* 
 * method is for updating  SB Accounts details */

	public boolean updateSBAccounts(SBAccount sbAccount) 
	{
		if(sbAccountDaoImpl.updateSBAccounts(sbAccount)){
			return true;	
		}
		else{
			return false;
		}
	}
	
}
