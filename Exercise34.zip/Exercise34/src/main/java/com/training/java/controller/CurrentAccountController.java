/*
 * CurrentAccountController
 * CurrentAccountController is acontroller class having a method .
 * 15-10-2020
 */

package com.training.java.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.training.java.dao.CurrentAccountDao;
import com.training.java.service.CurrentAccountService;
import com.ust.java.model.CurrentAccount;

/*
 * CurrentAccountController is acontroller class having a method .
 */

@Controller
public class CurrentAccountController {
	
	@Autowired
	private	CurrentAccountService currentAccountService;
	
	
	/*
	 * showForm is  a method to show currentAccount form .
	 */	
	@RequestMapping("/showCurrentAccountForm")
	public String showForm(Model model){
		CurrentAccount cAccount=new CurrentAccount();
		model.addAttribute("key",cAccount);
		
		return "addCurrentAccount";
		
	}
	
	/*
	 * addCurrentAccount is  a method to add currentAccount .
	 */	
	@RequestMapping("/addCurrentAccount")
	public String addCurrentAccount(@ModelAttribute("currentAccount") CurrentAccount cAccount) {
		
		
		currentAccountService.addCurrentAccounts(cAccount);
		
		return "redirect:/current";
		
		
	}
	
	
	/*
	 * getAllCurrentAccounts is  a method which returns view name .
	 */	
	
	@RequestMapping("/current")
	public String getAllCurrentAccounts(Model model){
		System.out.println("Inside CurrentAccountController getAllCurrentAccounts");
		List<CurrentAccount> currentAccountListList = currentAccountService.getAllCurrentAccounts();
		
		model.addAttribute("key",currentAccountListList );
		
		
		return "currentAccountList";
	}
	
	/*
	 * getCurrentAccount is  a method to dispaly particular account details .
	 */	
	@RequestMapping("/viewCurrentAccount")
	public String getCurrentAccount(@RequestParam("accNo")String accNo,Model model) {
		
		
		CurrentAccount currentAccount = currentAccountService.getCurrentAccountsByAccountNo(Integer.parseInt(accNo));
		
		model.addAttribute("key", currentAccount);
		
		
		return "viewCurrentAccount";
		
		
	}
	
	/*
	 * deleteCurrentAccount is  a method to delete particular account details .
	 */	
	@RequestMapping("/deleteCurrentAccount")
	public String deleteCurrentAccount(@RequestParam("accNo")String accNo,Model model) {
		
		
		currentAccountService.deleteCurrentAccount(Integer.parseInt(accNo));
		
		
		
		
		return "redirect:/current";

	}
	
}
