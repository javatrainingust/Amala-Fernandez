/***
 * CurrentOverDraftComparator 
 * CurrentOverDraftComparator is a  class for comparing using comparator
 * 07-10-2020
 * */

package com.training.java.bankingapplicationmaster.service;

import java.util.Comparator;

import com.training.java.bankingapplicationmaster.model.FDAccount;
/*** 
 * CurrentOverDraftComparator is a  class for comparing using comparator
 * */
public class FDBalanceComparator implements Comparator<FDAccount>{

	
	/*
	 * comparing two values
	 */
	public int compare(FDAccount one, FDAccount two) {
		
		return (int) (one.getBalance()-two.getBalance());
}
}