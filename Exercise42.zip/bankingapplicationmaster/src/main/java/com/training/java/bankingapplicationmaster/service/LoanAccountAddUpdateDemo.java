/***
 * LoanAccountAddUpdateDemo 
 * LoanAccountAddUpdateDemo is class for adding and updating LoanAccount
 * 08-10-2020
 * */

package com.training.java.bankingapplicationmaster.service;

import com.training.java.bankingapplicationmaster.model.FDAccount;
import com.training.java.bankingapplicationmaster.model.LoanAccount;
/*** 
 * LoanAccountAddUpdateDemo is class for adding and updating LoanAccount
 * */
public class LoanAccountAddUpdateDemo {
	/***
	 * main method
	 * */
	public static void main(String[] args) {
		LoanAccountDaoService loanAccountDaoService=new LoanAccountDaoService();
		loanAccountDaoService.addLoanAccounts(new LoanAccount(4000,"Amala",1,12000,7000));
		loanAccountDaoService.addLoanAccounts(new LoanAccount(4001,"Mary",2,7000,90000));
		loanAccountDaoService.addLoanAccounts(new LoanAccount(4001,"Mary",2,7000,90000));
		
		System.out.println("Printing all loanaccounts");	
		loanAccountDaoService.getAllLoanAccounts();
		
		System.out.println("---------------------------------------------");
		loanAccountDaoService.updateLoanAccounts(new LoanAccount(4001,"Mary",2,12000,90000));
		
		System.out.println("Printing all updated loanaccounts");	
		loanAccountDaoService.getAllLoanAccounts();

	}

}
