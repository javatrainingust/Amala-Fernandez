/***
 * Renewable 
 * interface is for auto renewal checking overdraft.
 * 30-09-2020
 * */
package com.training.java.bankingapplicationmaster.model;

/***
 * interface is for auto renewal checking overdraft.
 * */
public interface Renewable {
	/***
	 * autoRenewal method for renewing tenure.
	 * */
	public void autoRenewal(int tenure);
}
