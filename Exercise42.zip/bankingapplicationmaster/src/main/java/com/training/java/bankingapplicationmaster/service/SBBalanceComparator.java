/***
 * SBBalanceComparator 
 * SBBalanceComparator is a  class for comparing using comparator
 * 07-10-2020
 * */
package com.training.java.bankingapplicationmaster.service;

import java.util.Comparator;

import com.training.java.bankingapplicationmaster.model.FDAccount;
import com.training.java.bankingapplicationmaster.model.SBAccount;
/***
 * SBBalanceComparator is a  class for comparing using comparator
 * */
public class SBBalanceComparator implements  Comparator<SBAccount>{
	
	/*
	 * comparing two values
	 */
	public int compare(SBAccount one, SBAccount two) {
		
		return (int) (one.getBalance()-two.getBalance());
}
}