/***
 * CurrentAccountDaoImplTest 
 * CurrentAccountDaoImplTest is a test class for CurrentAccountDaoImpl
 * 06-10-2020
 * */
package com.training.java.bankingapplicationmaster.dao;



import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.training.java.bankingapplicationmaster.model.CurrentAccount;

/***
 * CurrentAccountDaoImplTest is a test class for CurrentAccountDaoImpl
 * */
public class CurrentAccountDaoImplTest {
	
	List expectedList;
	
	/***
	 * CurrentAccountDaoImplTest  class constructor
	 * */
	public CurrentAccountDaoImplTest()
	{
		expectedList=new ArrayList<CurrentAccount>();
		CurrentAccount currentAccount1=new CurrentAccount(3000,"Amala",10000,5000);
		CurrentAccount currentAccount2=new CurrentAccount(3001,"Mary",25000,15000);
		CurrentAccount currentAccount3=new CurrentAccount(3002,"Carmel",12000,5000);
		CurrentAccount currentAccount4=new CurrentAccount(3003,"Fernandez",50000,25000);
		CurrentAccount currentAccount5=new CurrentAccount(3004,"Nia",140000,25000);
		
		expectedList.add(currentAccount1);
		expectedList.add(currentAccount2);
		expectedList.add(currentAccount3);
		expectedList.add(currentAccount4);
		expectedList.add(currentAccount5);
	}
/*
 *  Test method for getAllCurrentAccounts
 */
	@Test
	public void testGetAllCurrentAccounts() {
		CurrentAccountDaoImpl currentAccountDaoImpl=new CurrentAccountDaoImpl();
		List actualList=currentAccountDaoImpl.getAllCurrentAccounts();
		assertEquals(expectedList.size(),actualList.size());
	}
	/* 
	 * Test method for getCurrentAccountsByAccountNo
	 */
	@Test
	public void testGetCurrentAccountsByAccountNo() {
		String expectedValue="Fernandez";
		CurrentAccountDaoImpl currentAccountDaoImpl=new CurrentAccountDaoImpl();
		CurrentAccount actualValue=currentAccountDaoImpl.getCurrentAccountsByAccountNo(3003);
		assertEquals(expectedValue,actualValue.getAccountHolderName());
	}
	/* 
	 * Test method for deleteCurrentAccount
	 */
	@Test
	public void testDeleteCurrentAccount() {
		CurrentAccountDaoImpl currentAccountDaoImpl=new CurrentAccountDaoImpl();
		currentAccountDaoImpl.deleteCurrentAccount(3002);;
		List actualValue= currentAccountDaoImpl.getAllCurrentAccounts();
		assertEquals(expectedList.size()-1,actualValue.size());
	}

}
