
/***
 * FDAccountServiceTest 
 * FDAccountServiceTest is test class for FDAccountService
 * 07-10-2020
 * */
package com.training.java.bankingapplicationmaster.service;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.training.java.bankingapplicationmaster.model.CurrentAccount;
import com.training.java.bankingapplicationmaster.model.FDAccount;
/***
 * FDAccountServiceTest is test class for FDAccountService
 * */
public class FDAccountServiceTest {
	
	
	FDAccountService fdAccountService;

	/** 
	 * Constructor for CurrentAccountServiceTest */

	public FDAccountServiceTest() {
		fdAccountService = new FDAccountService();
	

		fdAccountService.addFdAccounts(new FDAccount(1000,"Amala",12000,1));
		fdAccountService.addFdAccounts(new FDAccount(1001,"Mary",15000,1));
			}
	
	
	/** 
	 * Method  for add account  Success
	 * */
				@Test
		public void testAddCurrentAccountsSuccess() {
					
	assertTrue(fdAccountService.addFdAccounts(new FDAccount(1002,"Amala",12000,1)));

			}
				/**
				 *  Method  for add account  failure*/
		@Test
		public 	void testAddCurrentAccountsFailure() {
		assertFalse(fdAccountService.addFdAccounts(new FDAccount(1000,"Amala",12000,1)));
				
		}
		/** 
		 * Method  for update account  Success*/
		
		public void testUpdateFdAccountsSuccess()
		 {
			assertTrue(fdAccountService.updateFdAccounts(new FDAccount(1001,"Mary",15000,1)));
		 }
	
/** 
 * Method  for update account  Failure*/
		
		public void testUpdateFdAccountsFailure()
		 {
			assertTrue(fdAccountService.updateFdAccounts(new FDAccount(1008,"Mary",15000,1)));
		 }
	
	
	

	/* for getting all accounts  sorted by names

	@Test
	public void testGetAllFDAccountsSortedByNames() {
		String expectedValue ="Fernandez";
		 FDAccountService  fdAccountService=new  FDAccountService();
		List<FDAccount> fdAccountServiceList=fdAccountService.getAllFDAccountsSortedByNames();
		String actualValue=fdAccountServiceList.get(2).getAccountHolderName();
		assertEquals(expectedValue,actualValue);
	}
	 for getting all accounts  sorted by balance

	@Test
	public void testGetAllFDAccountsSortedByBalance() {
		float expectedValue =6000;
		 FDAccountService  fdAccountService=new  FDAccountService();
		List<FDAccount> fdAccountServiceList=fdAccountService.getAllFDAccountsSortedByBalance();
		float actualValue=fdAccountServiceList.get(0).getBalance();
		assertEquals(expectedValue,actualValue,0.0f);
	}*/

}
