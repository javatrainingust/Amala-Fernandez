/***
 * FDAccountDaoImpl 
 * FDAccountDaoImpl is an implementation class for FDAccountDao
 * 06-10-2020
 * */
package com.training.java.bankingapplicationmaster.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Repository;

import com.training.java.bankingapplicationmaster.model.FDAccount;

/***
 * FDAccountDaoImpl is an implementation class for FDAccountDao
 * */


public class FDAccountDaoImpl implements FDAccountDao  {

	List fdAccountList;
	private Set fdAccountSet;
	
	/***
	 * FDAccountDaoImpl class constructor
	 * */
	public FDAccountDaoImpl()
	{
		fdAccountList=new ArrayList<FDAccount>();
		fdAccountSet=new HashSet<FDAccount>();
		FDAccount fdAccount1=new FDAccount(1000,"Amala",12000,1);
		FDAccount fdAccount2=new FDAccount(1001,"Mary",14000,1);
		FDAccount fdAccount3=new FDAccount(1002,"Carmel",20000,1);
		FDAccount fdAccount4=new FDAccount(1003,"Fernandez",50000,1);
		FDAccount fdAccount5=new FDAccount(1004,"Nia",6000,1);
		
		fdAccountList.add(fdAccount1);
		fdAccountList.add(fdAccount2);
		fdAccountList.add(fdAccount3);
		fdAccountList.add(fdAccount4);
		fdAccountList.add(fdAccount5);
		
	}
	
	
	/* 
	 * getAllFDAccounts method is for getting all the FDAccount 
	 */
	public List<FDAccount> getAllFDAccounts() {
		
		return fdAccountList;
	}
	/* 
	 * getFDAccountsByAccountNo method is for getting particular FDAccount 
	 */
	public FDAccount getFDAccountsByAccountNo(int accountNo) {
		
		
		FDAccount fdAccount=null;
		Iterator<FDAccount> iterator = fdAccountList.iterator();
		while(iterator.hasNext()){
			FDAccount FAccount=iterator.next();
              if(FAccount.getAccountNo()==accountNo){
				
				 fdAccount = FAccount;
			}
			
			
		}
			
		
		return fdAccount;
	}

	/* 
	 * deleteFDAccount method is for deleting particular FDAccount 
	 */
	public void deleteFDAccount(int accountNo) {
		FDAccount fdAccount=null;
		Iterator<FDAccount> iterator = fdAccountList.iterator();
		while(iterator.hasNext()){
			FDAccount FAccount=iterator.next();
              if(FAccount.getAccountNo()==accountNo){
            	  
            	  fdAccount=FAccount;
			}
              
			
		}
			
		fdAccountList.remove(fdAccount);
		
		
	}

	/* 
	 *  method is for adding  FDAccounts
	 */
	public boolean addFdAccounts(FDAccount fdAccount) {
		boolean isAdded=fdAccountSet.add(fdAccount);
		
		if(isAdded){
			fdAccountList.add(fdAccount);
		}
		return isAdded;
	}

	 /* 
	  * method is for updating  FDAccounts details 
	  */
	public boolean updateFdAccounts(FDAccount fdAccount) {
		
		Iterator<FDAccount> iterator = fdAccountList.iterator();
		while(iterator.hasNext()){
			FDAccount fAccount=iterator.next();
              if(fAccount.getAccountNo()==fdAccount.getAccountNo()){
            	  
            	  fAccount.setAccountNo(fdAccount.getAccountNo());
            	  fAccount.setAccountHolderName(fdAccount.getAccountHolderName());
            	  fAccount.setBalance(fdAccount.getBalance());
            	  fAccount.setTenure(fdAccount.getTenure());
			}
	}

	return true;
	
	}

}
