/***
 * CurrentAccountDaoSqlImpl 
 * CurrentAccountDaoSqlImpl is an implementation class for CurrentAccountDao
 * 23-10-2020
 * */

package com.training.java.bankingapplicationmaster.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.training.java.bankingapplicationmaster.model.CurrentAccount;

/***
 * CurrentAccountDaoSqlImpl is an implementation class for CurrentAccountDao
 * */
@Repository
public class CurrentAccountDaoSqlImpl implements CurrentAccountDao {

	@Autowired
	private JdbcTemplate jdbcTemplateObject;
	
	
	
	
	/*
	 *  getAllCurrentAccounts method is for getting all the CurrentAccount 
	 */
	
	public List<CurrentAccount> getAllCurrentAccounts() {
		String sql="select * from currentaccount";
		List<CurrentAccount> currentsAccounts=jdbcTemplateObject.query(sql,new CurrentAccountMapper());
		
		return currentsAccounts;
	}
	
	/* 
	 * getCurrentAccountsByAccountNo method is for getting particular CurrentAccount 
	 */

	public CurrentAccount getCurrentAccountsByAccountNo(int accountNo) {
		String sql="select * from currentaccount where accountNo=?";
		CurrentAccount currentsAccounts=jdbcTemplateObject.queryForObject(sql, new Object[] {accountNo}, new CurrentAccountMapper());
		
		return currentsAccounts;
	}

	/* 
	 * deleteCurrentAccount method is for deleting particular CurrentAccount 
	 */
	
	public void deleteCurrentAccount(int accountNo) {
		String query="delete from currentaccount where accountNo='"+accountNo+"' ";  
		jdbcTemplateObject.update(query); 
	}

	/* 
	 *  method is for adding  Current Accounts 
	 */
	
	public boolean addCurrentAccounts(CurrentAccount currentAccount) {
		String sql="insert into currentaccount(accountNo,accountHolderName,balance,OverDraftLimit)values(?,?,?,?)";
		jdbcTemplateObject.update(sql, new Object[] {currentAccount.getAccountNo(),currentAccount.getAccountHolderName(),currentAccount.getBalance(),currentAccount.getOverDraftLimit()});
		return true;
	}

	/* 
	 * method is for updating  Current Accounts details 
	 */
	
	public boolean updateCurrentAccounts(CurrentAccount currentAccount) {
		String query="update currentaccount set  accountNo='"+currentAccount.getAccountNo()+"',accountHolderName='"+currentAccount.getAccountHolderName()+"',balance='"+currentAccount.getBalance()+"',OverDraftLimit='"+currentAccount.getOverDraftLimit()+"' where accountNo='"+currentAccount.getAccountNo()+"' ";  
	    jdbcTemplateObject.update(query);  

		return false;
	}

}
