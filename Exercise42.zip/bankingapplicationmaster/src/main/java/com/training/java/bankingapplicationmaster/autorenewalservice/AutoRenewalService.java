package com.training.java.bankingapplicationmaster.autorenewalservice;
import com.training.java.bankingapplicationmaster.model.FDAccount;
import com.training.java.bankingapplicationmaster.model.Renewable;

public class AutoRenewalService {

	public static void main(String args[]){
		Renewable ar=new FDAccount();
		ar.autoRenewal(7);
	}
	
}
