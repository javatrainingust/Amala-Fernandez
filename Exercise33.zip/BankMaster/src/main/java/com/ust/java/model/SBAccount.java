/**
 * SBAccount
 * SBAccount class includes SBaccount details
 * 30-09-2020
 */
package com.ust.java.model;
import com.training.java.exception.InsufficientBalanceException;
import com.ust.java.util.ICalculator;
import com.ust.java.util.IntrestCalculation;
/**
 * SBAccount class includes SBaccount details
 */
public class SBAccount extends Account implements Comparable<SBAccount> {

	private float duration;
	
	IntrestCalculation interest = new IntrestCalculation();
	/***
	 * SBAccount class default constructor
	 * */
	public SBAccount() {
		System.out.println("inside SBAccount default constructor");
	}
	/***
	 * SBAccount class parameterised constructor
	 * */
	public SBAccount(int accountNo,String accountHolderName,float balance, float duration) {
		super(accountNo,accountHolderName,balance);
		this.duration = duration;
		//System.out.println("inside SBAccount parameterised constructor");
	}

	/*
	 * getter method for duration
	 * */
	
	public void setDuration(float duration) {
		this.duration = duration;
	}
	
	/*
	 * setter method for duration
	 * */
	public float getDuration() {
		return duration;
	}
	
	/* 
	 * withdrawMoney method for withdrawing money
	 *  */

	public void withdrawMoney(float amountWithdrawn) throws InsufficientBalanceException {
		
		if(amountWithdrawn>this.balance){
			throw new InsufficientBalanceException(amountWithdrawn);
		}
		else{
		balance = balance - amountWithdrawn;
		System.out.println("Account balance after withdrawing is :" + balance);
	}
	}
	/*
	 *  interestCalculation method for calculating interest 
	 *  */

	public void interestCalculation(float amount, ICalculator interest) {

		float sbinterest = interest.calculateInterest(amount, duration);
		System.out.println("savings bank interest" + sbinterest);
	}

	
	/*
	 *  compareto method 
	 *  */
	public int compareTo(SBAccount sAccount) {
		
		return this.accountHolderName.compareTo(sAccount.getAccountHolderName());
	}
}
