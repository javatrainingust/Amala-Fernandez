/*
 * RestclientApplication
 * RestclientApplication is a spring boot application class.
 * 28-10-2020
 * */

package com.training.java.restclient;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.training.java.bankingapplicationmaster.model.CurrentAccount;
/*
 * RestclientApplication is a spring boot application class.
 * */
@SpringBootApplication
public class RestclientApplication {

	/*
	 * main method
	 * */
	public static void main(String[] args) {
		SpringApplication.run(RestclientApplication.class, args);
		//postCurrentAccount();;
		//putCurrentAccount();
		//deleteCurrentAccount();
		getAllCurrentAccount();
		//getCurrentAccount();
	}
	
	/*
	 *  method for getting specefic current account
	 * */
public static void  getCurrentAccount() {
		
	System.out.println("Inside getCurrentAccount() method");
	
		RestTemplate restTemplate = new RestTemplate();
		
		final String uri = "http://localhost:8080/bankingapplicationmaster/currentAccounts/{id}";
	    	     
	    Map<String, Integer> params = new HashMap<String, Integer>();
	    params.put("id", 7002);
	     
	    CurrentAccount cAccount = restTemplate.getForObject(uri, CurrentAccount.class, params);
	    
	    System.out.println("Account no: "+cAccount.getAccountNo());
	    System.out.println("Account holder name: "+cAccount.getAccountHolderName());
	    System.out.println("balance: "+cAccount.getBalance());
	    System.out.println("OverDraftLimit: "+cAccount.getOverDraftLimit());
		
	}
	

	
/*
 *  method for getting all current account
 * */
public static void getAllCurrentAccount() {
		
		System.out.println("Inside getAllCurrentAccount() method");
	
		
		RestTemplate restTemplate = new RestTemplate();
		
		final String uri = "http://localhost:8080/bankingapplicationmaster/currentAccounts";
	    	     
	    	     
	    ResponseEntity<CurrentAccount[]> response  = restTemplate.getForEntity(uri, CurrentAccount[].class);
	    
	    CurrentAccount[] accounts = response.getBody();

	    
	    for(int i=0; i<accounts.length;i++) {
	    	
	    	CurrentAccount cAccount= (CurrentAccount)accounts[i];	    
	    System.out.println("Account no: "+cAccount.getAccountNo());
	    System.out.println("Account holder name: "+cAccount.getAccountHolderName());
	    System.out.println("balance: "+cAccount.getBalance());
	    System.out.println("OverDraftLimit: "+cAccount.getOverDraftLimit());
	    }
		
	    
		
	}

/*
 *  method for adding current account
 * */
public static void postCurrentAccount() {
	
	
	RestTemplate restTemplate = new RestTemplate();
	
	final String uri = "http://localhost:8080/bankingapplicationmaster/currentAccounts";

	CurrentAccount pe = new CurrentAccount(5004,"Mohan",1000000,5000);

	CurrentAccount result = restTemplate.postForObject( uri, pe, CurrentAccount.class);
	
	
}

/*
 *  method for updating specefic current account
 * */
public static void putCurrentAccount() {
	
	RestTemplate restTemplate = new RestTemplate();
	
	final String uri = "http://localhost:8080/bankingapplicationmaster/currentAccounts/{id}";
    	     
    Map<String, Integer> params = new HashMap<String, Integer>();
    params.put("id", 5004);
     
    CurrentAccount cAccount = new CurrentAccount(5004,"Mohan kumar",1000000,5000);
    
     restTemplate.put(uri, cAccount, params);
	
	
	
	
}

/*
 *  method for deleting specefic current account
 * */
public static void deleteCurrentAccount() {
	
	RestTemplate restTemplate = new RestTemplate();
	
	final String uri = "http://localhost:8080/bankingapplicationmaster/currentAccounts/{id}";
    	     
    Map<String, Integer> params = new HashMap<String, Integer>();
    params.put("id", 5004);
     
     restTemplate.delete(uri, params);
}




}
