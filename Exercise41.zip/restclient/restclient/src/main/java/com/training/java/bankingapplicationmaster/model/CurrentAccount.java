/***
 * CurrentAccount 
 * class extends Account class
 * 30-09-2020
 * */
package com.training.java.bankingapplicationmaster.model;
/***
 * CurrentAccount 
 * class extends Account class
 * */
public class CurrentAccount extends Account implements Comparable<CurrentAccount> {
    
    float OverDraftLimit;
    // float balance;
    
    /***
 	 * CurrentAccount class default constructor
 	 * */
    
    public CurrentAccount(){
    	//System.out.println("inside CurrentAccount default constructor");
    }  
    
    /***
	 * Account class parameterised constructor
	 * */
    
    public CurrentAccount(int accountNo, String accountHolderName,float balance,float OverDraftLimit) {
		super(accountNo,accountHolderName,balance);
		this.OverDraftLimit=OverDraftLimit;
		//System.out.println("inside CurrentAccount parameterised constructor");
	}
    /*
     * getter method for OverDraftLimit 
     * */

    public float getOverDraftLimit() {
		return OverDraftLimit;
	}
    /*
     * setter method for OverDraftLimit
     * */
	public void setOverDraftLimit(float overDraftLimit) {
		OverDraftLimit = overDraftLimit;
	}
	 /* 
	  * CheckOverDraft is for checking overdraft amount
	  *  */
	public String CheckOverDraft(float balance)
    {
    /*condition check */
    if(balance>=50000)
    {
          return "Overdraft limit is 25000 as balance is above 50000";
    }
    
    else if(balance >25000 && balance <50000)
    	return "Overdraft limit is 15000 as balance is between 25000 and 50000";
    
    else
    	return "Overdraft limit is 5000 as balance is below 25000";

    }

	

	
	/* 
	 * compareto method
	 *  */

	@Override
	public String toString() {
		return "CurrentAccount [OverDraftLimit=" + OverDraftLimit + ", accountHolderName=" + accountHolderName
				+ ", balance=" + balance + "]";
	}

	public int compareTo(CurrentAccount currentAccount) {
		
		return this.accountHolderName.compareTo(currentAccount.getAccountHolderName());
	}
}

