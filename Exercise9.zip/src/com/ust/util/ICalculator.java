package com.ust.util;
/**
 * 
 * @author 100798
 *ICalculator is an interface having two declared methods
 */
public interface ICalculator {
	
	
	/*calculateInterest method calculate the interest and takes one argument that is amount*/
	public float calculateInterest(float amount);
	
	
	/*calculateInterest method calculate the interest and takes two arguments that is amount and duration*/
	public float calculateInterest(float amount,float duration);
}
