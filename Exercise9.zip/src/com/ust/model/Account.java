package com.ust.model;

/***
 * Account class is having private variables and setters and getters for private variables.And has a interestCalculation method 
 */

import com.ust.util.ICalculator;
import com.ust.util.IntrestCalculation;



public class Account {
  private int accountNo;
  private String accountHolderName;
  private float balance=50000;
  
  public Account()
  {
	  System.out.println("inside account default constructor");
  }
public Account(int accountNo, String accountHolderName) {
	super();
	this.accountNo = accountNo;
	this.accountHolderName = accountHolderName;
	System.out.println("inside account parameterised constructor");
}
public int getAccountNo() {
	return accountNo;
}
public void setAccountNo(int accountNo) {
	this.accountNo = accountNo;
}
public String getAccountHolderName() {
	return accountHolderName;
}
public void setAccountHolderName(String accountHolderName) {
	this.accountHolderName = accountHolderName;
}
public float getBalance() {
	return balance;
}

  
 
//IntrestCalculation interest=new IntrestCalculation();



/*interestCalculation for calculating interest and take two argument */ 


public void interestCalculation(float amount,ICalculator interest){
float fdinterest=interest.calculateInterest( amount);
System.out.println("Account interest"+fdinterest);
}


}