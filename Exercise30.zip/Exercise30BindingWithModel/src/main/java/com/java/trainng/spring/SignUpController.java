/*
 * SignUpController
 * SignUpController is a conroller class having mthods
 * 15-10-2020
 */

package com.java.trainng.spring;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;


/*
 * SignUpController is a conroller class having mthods
 */
@Controller
public class SignUpController {

	
	/*
	 * showForm method takes an an argument and returns a value
	 */
	@RequestMapping("/showForm")
	public String showForm(Model theModel) {
		
		// create a student object
		SignUp theSignup = new SignUp();
		
		

		// add student object to the model
		theModel.addAttribute("key", theSignup);
		
		return "signUp";
	}
	
	/*
	 * processForm method takes an arguments and returns a value
	 */
	@RequestMapping("/processForm")
	public String processForm(@ModelAttribute("signUp") SignUp theSignup)
	{
		return "confirmSignUp";
	}
	
}
