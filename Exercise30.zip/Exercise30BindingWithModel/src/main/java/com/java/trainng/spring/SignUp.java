/*
 * SignUp
 * SignUp is a model class having instance variable,getter and setter methods.
 * 15-10-2020
 */

package com.java.trainng.spring;
/*
 * SignUp is a model class having instance variable,getter and setter methods.
 */
public class SignUp {

	private String userName;
	private String userId;
	private String password;
	private String confirmPassword;
	
	/*
	 * getter method for userName
	 */
	
	public String getUserName() {
		return userName;
	}
	
	/*
	 * setter method for userName
	 */
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	/*
	 * getter method for userId
	 */
	
	public String getUserId() {
		return userId;
	}
	/*
	 * setter method for userId 
	 */
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	/*
	 * getter method for password
	 */
	
	public String getPassword() {
		return password;
	}
	
	/*
	 * setter method for password
	 */
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	/*
	 * getter method for confirmPassword
	 */
	
	public String getConfirmPassword() {
		return confirmPassword;
	}
	/*
	 * setter method for confirmPassword
	 */
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	
	
	
}
