package com.ust.util;

public class IntrestCalculation {
//float Rate=0.3f;
float fdRate=0.7f;
float sbRate=0.5f;
float  duration=1;



public float calculateInterest(float amount){
float interestamountfd=(amount*fdRate*duration)/100 ;
return interestamountfd;
}
public float calculateInterest(float amount,float duration){
float interestamountsb=(amount*sbRate*duration)/100 ;
return interestamountsb;
}
}
