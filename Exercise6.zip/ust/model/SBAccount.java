package com.ust.model;



import com.ust.util.IntrestCalculation;

public class SBAccount extends Account {

	private float balance=50000;
	IntrestCalculation interest=new IntrestCalculation();
    
    public void withdrawMoney(float amountWithdrawn)
    {
          balance=balance- amountWithdrawn;
          System.out.println("Account balance after withdrawing is :" +balance);
    }

    public void interestCalculation(float amount,float duration){
    	float sbinterest=interest.calculateInterest( amount,duration);
    	System.out.println(sbinterest);
    	}
}

