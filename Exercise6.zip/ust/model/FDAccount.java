package com.ust.model;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


import com.ust.util.IntrestCalculation;

public class FDAccount extends Account implements Renewable {

    public int tenure=10;
  public  String maturityDate="28/09-2020";
   
   
   
   
    Calendar calendar = Calendar.getInstance();  
    IntrestCalculation interest=new IntrestCalculation();
   
   
public void interestCalculation(float amount){
float fdinterest=interest.calculateInterest( amount);
System.out.println(fdinterest);
}

@Override
public void autoRenewal(int tenure) {
// TODO Auto-generated method stub

boolean isAutoRenewal = (tenure>5)?true:false;
     System.out.println("Is FDAccount need auto renewal? " +isAutoRenewal);

}

}

