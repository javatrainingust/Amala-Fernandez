package com.ust.model;

import com.ust.util.IntrestCalculation;



public class Account {
  private int accountNo;
  private String accountHolderName;
  private float balance=50000;
  
  
public int getAccountNo() {
	return accountNo;
}
public void setAccountNo(int accountNo) {
	this.accountNo = accountNo;
}
public String getAccountHolderName() {
	return accountHolderName;
}
public void setAccountHolderName(String accountHolderName) {
	this.accountHolderName = accountHolderName;
}
public float getBalance() {
	return balance;
}

  
 
IntrestCalculation interest=new IntrestCalculation();

public void interestCalculation(float amount){
float fdinterest=interest.calculateInterest( amount);
System.out.println(fdinterest);
}


}