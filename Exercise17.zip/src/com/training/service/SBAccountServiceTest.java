/***
 * SBAccountServiceTest 
 * SBAccountServiceTest is  class for displaying details
 * 07-10-2020
 * */
package com.training.service;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.ust.model.FDAccount;
import com.ust.model.SBAccount;
/***
 * SBAccountService 
 * SBAccountServiceTest is test class for SBAccountService
 * 06-10-2020
 * */
public class SBAccountServiceTest {
	/* for getting all accounts  sorted by names*/
	@Test
	public void testGetAllSBAccountsSortedByNames() {
		String expectedValue ="Anna";
		SBAccountService  sbAccountService=new  SBAccountService();
		List<SBAccount> sbAccountServiceList=sbAccountService.getAllSBAccountsSortedByNames();
		String actualValue=sbAccountServiceList.get(0).getAccountHolderName();
		assertEquals(expectedValue,actualValue);
	}
	/* for getting all accounts  sorted by balance*/
	@Test
	public void testGetAllSBAccountsSortedByBalance() {
		float expectedValue =20000;
		SBAccountService  sbAccountService=new  SBAccountService();
		List<SBAccount> sbAccountServiceList=sbAccountService.getAllSBAccountsSortedByBalance();
		float actualValue=sbAccountServiceList.get(1).getBalance();
		assertEquals(expectedValue,actualValue,0.0f);
	}

}
