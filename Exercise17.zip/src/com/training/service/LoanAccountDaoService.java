/***
 * LoanAccountDaoService 
 * LoanAccountDaoService is  class for displaying details
 * 06-10-2020
 * */

package com.training.service;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.training.dao.CurrentAccountDao;
import com.training.dao.CurrentAccountDaoImpl;
import com.training.dao.LoanAccountDao;
import com.training.dao.LoanAccountDaoImpl;
import com.ust.model.CurrentAccount;
import com.ust.model.LoanAccount;
/***
 * LoanAccountDaoService is  class for displaying details
 * */
public class LoanAccountDaoService {
	 LoanAccountDao  loanAccountImpl;
	 /***
	  * LoanAccountDaoService   class constructor
	  ** */
	public LoanAccountDaoService(){
		
		loanAccountImpl=new LoanAccountDaoImpl();
	}
	
	
	/* for dispalying all the LoanAccount */
	 
	public List<LoanAccount> getAllLoanAccounts() 
	{
		List loanAccountList=loanAccountImpl.getAllLoanAccounts();
		Iterator<LoanAccount> iterator = loanAccountList.iterator();
		while(iterator.hasNext()){
			LoanAccount loanAccount=iterator.next();
			
			System.out.println("Account No "+loanAccount.getAccountNo());
			System.out.println("Account Holder Name"+loanAccount.getAccountHolderName());
			System.out.println("tenure "+loanAccount.getTenure());
		}
			return loanAccountList;
	}
	
	/*for displaying particular LoanAccount */
	 
		public LoanAccount getLoanAccountsByAccountNo(int accountNo) 
		{
			LoanAccount loanAccount=loanAccountImpl.getLoanAccountsByAccountNo(accountNo);
			System.out.println("Account No "+loanAccount.getAccountNo());
			System.out.println("Account Holder Name"+loanAccount.getAccountHolderName());
			System.out.println("tenure "+loanAccount.getTenure());
			return loanAccount;
		}
		
		/* for deleting particular LoanAccount */
		
		public void deleteLoanAccount(int accountNo) {
			
			loanAccountImpl.deleteLoanAccount(accountNo);	
		}
		
/* for getting all accounts  sorted by names*/
		
		public List<LoanAccount>	getAllCurrentAccountsSortedByNames(){
			
			
			List<LoanAccount> currentAccountList = loanAccountImpl.getAllLoanAccounts();
			
			Collections.sort(currentAccountList);
			
			
			Iterator<LoanAccount> iterator = currentAccountList.iterator();
			
			while(iterator.hasNext()){
				
				LoanAccount loanAccount = iterator.next();
				
				System.out.println("Account No "+loanAccount.getAccountNo());
				System.out.println("Account Holder Name"+loanAccount.getAccountHolderName());
				System.out.println("tenure "+loanAccount.getTenure());
				
				}			
			
			
			
			return currentAccountList;
		}
		
		
/* for getting all accounts  sorted by balance*/
		
		public List<LoanAccount>	getAllCurrentAccountsSortedByOutStandingAmount(){
			
			
			List<LoanAccount> currentAccountList = loanAccountImpl.getAllLoanAccounts();
			
			Collections.sort(currentAccountList,new LoanBalanceComparator());
			
			
			Iterator<LoanAccount> iterator = currentAccountList.iterator();
			
			while(iterator.hasNext()){
				
				LoanAccount loanAccount = iterator.next();
				
				System.out.println("Account No "+loanAccount.getAccountNo());
				System.out.println("Account Holder Name"+loanAccount.getAccountHolderName());
				System.out.println("tenure "+loanAccount.getTenure());
				System.out.println("Loanouitstanding amount "+loanAccount.getLoanOutstanding());
				}			
			
			
			
			return currentAccountList;
		}
		
		
}
