/***
 * LoanAccountDaoServiceTest 
 * LoanAccountDaoServiceTest is  test class for LoanAccountDaoService
 * 07-10-2020
 * */
package com.training.service;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.ust.model.FDAccount;
import com.ust.model.LoanAccount;
/***
 *LoanAccountDaoServiceTest is  test class for LoanAccountDaoService
 * */
public class LoanAccountDaoServiceTest {

	/* for getting all accounts  sorted by names*/
	@Test
	public void testGetAllCurrentAccountsSortedByNames() {
		String expectedValue ="Fernandez";
		LoanAccountDaoService  loanAccountDaoService=new  LoanAccountDaoService();
		List<LoanAccount> loanAccountDaoServiceList=loanAccountDaoService.getAllCurrentAccountsSortedByNames();
		String actualValue=loanAccountDaoServiceList.get(2).getAccountHolderName();
		assertEquals(expectedValue,actualValue);
	}
	/* for getting all accounts  sorted by Loanouitstanding amount*/
	@Test
	public void testGetAllCurrentAccountsSortedByOutStandingAmount() {
		float expectedValue =3000;
		LoanAccountDaoService  loanAccountDaoService=new  LoanAccountDaoService();
		List<LoanAccount> loanAccountDaoServiceList=loanAccountDaoService.getAllCurrentAccountsSortedByOutStandingAmount();
		float actualValue=loanAccountDaoServiceList.get(0).getLoanOutstanding();
		assertEquals(expectedValue,actualValue,0.0f);
	}

}
