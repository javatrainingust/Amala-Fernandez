
/***
 * FDAccountServiceTest 
 * FDAccountServiceTest is test class for FDAccountService
 * 07-10-2020
 * */
package com.training.service;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.ust.model.CurrentAccount;
import com.ust.model.FDAccount;
/***
 * FDAccountServiceTest is test class for FDAccountService
 * */
public class FDAccountServiceTest {

	/* for getting all accounts  sorted by names*/

	@Test
	public void testGetAllFDAccountsSortedByNames() {
		String expectedValue ="Fernandez";
		 FDAccountService  fdAccountService=new  FDAccountService();
		List<FDAccount> fdAccountServiceList=fdAccountService.getAllFDAccountsSortedByNames();
		String actualValue=fdAccountServiceList.get(2).getAccountHolderName();
		assertEquals(expectedValue,actualValue);
	}
	/* for getting all accounts  sorted by balance*/

	@Test
	public void testGetAllFDAccountsSortedByBalance() {
		float expectedValue =6000;
		 FDAccountService  fdAccountService=new  FDAccountService();
		List<FDAccount> fdAccountServiceList=fdAccountService.getAllFDAccountsSortedByBalance();
		float actualValue=fdAccountServiceList.get(0).getBalance();
		assertEquals(expectedValue,actualValue,0.0f);
	}

}
