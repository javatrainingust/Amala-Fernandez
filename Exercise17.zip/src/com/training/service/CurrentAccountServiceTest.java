/***
 * CurrentAccountServiceTest 
 * CurrentAccountServiceTest is a test class for CurrentAccountService
 * 07-10-2020
 * */

package com.training.service;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.ust.model.CurrentAccount;
/***
 * CurrentAccountServiceTest is  class for displaying details
 * */
public class CurrentAccountServiceTest {

	/* for getting all accounts  sorted by names*/
 
	@Test
	public void testGetAllCurrentAccountsSortedByNames() {
		String expectedValue ="Mary";
		CurrentAccountService currentAccountService=new CurrentAccountService();
		List<CurrentAccount> currentAccountServiceList=currentAccountService.getAllCurrentAccountsSortedByNames();
		String actualValue=currentAccountServiceList.get(3).getAccountHolderName();
		assertEquals(expectedValue,actualValue);
	}
	/* for getting all accounts  sorted by over draft limit*/
	@Test
	public void testGetAllCurrentAccountsSortedByOverDraftLimit() {
		float expectedValue =5000;
		CurrentAccountService currentAccountService=new CurrentAccountService();
		List<CurrentAccount> currentAccountServiceList=currentAccountService.getAllCurrentAccountsSortedByOverDraftLimit();
		float actualValue=currentAccountServiceList.get(0).getOverDraftLimit();
		assertEquals(expectedValue,actualValue,0.0f);
	}

}
