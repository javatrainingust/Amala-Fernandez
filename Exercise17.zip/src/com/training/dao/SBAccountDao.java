/***
 * SBAccountDao 
 * SBAccountDao is an interface 
 * 06-10-2020
 * */

package com.training.dao;

import java.util.List;

import com.ust.model.FDAccount;
import com.ust.model.SBAccount;

/***
 * SBAccountDao is an interface 
 * */
public interface SBAccountDao {
	/* getAllSBAccounts method is for getting all the SBAccounts */
	public List<SBAccount> getAllSBAccounts();

	/* getSBAccountsByAccountNo method is for getting particular SBAccount */
	public SBAccount getSBAccountsByAccountNo(int accountNo);

	/* deleteSBAccount method is for deleting particular SBAccount */
	public void deleteSBAccount(int accountNo);

}
