/***
 * LoanAccountDaoImpl 
 * LoanAccountDaoImpl is an implementation class for LoanAccountDao
 * 06-10-2020
 * */
package com.training.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ust.model.CurrentAccount;
import com.ust.model.LoanAccount;

/***
 * LoanAccountDaoImpl is an implementation class for LoanAccountDao
 * */
public class LoanAccountDaoImpl implements LoanAccountDao {

	List loanAccountList;
	
	/***
	 * LoanAccountDaoImpl class constructor
	 * */
	public LoanAccountDaoImpl()
	{
		loanAccountList=new ArrayList<LoanAccount>();
		LoanAccount loanAccount1=new LoanAccount(4000,"Amala",1,12000,7000);
		LoanAccount loanAccount2=new LoanAccount(4001,"Mary",2,7000,90000);
		LoanAccount loanAccount3=new LoanAccount(4002,"Carmel",2,6000,3000);
		LoanAccount loanAccount4=new LoanAccount(4003,"Fernandez",3,40000,50000);
		LoanAccount loanAccount5=new LoanAccount(4004,"Nia",4,1000,15200);
		
		loanAccountList.add(loanAccount1);
		loanAccountList.add(loanAccount2);
		loanAccountList.add(loanAccount3);
		loanAccountList.add(loanAccount4);
		loanAccountList.add(loanAccount5);
		
	}
	
	
	/* getAllLoanAccounts method is for getting all the LoanAccount */
	
	@Override
	public List<LoanAccount> getAllLoanAccounts() {
		
		return loanAccountList;
	}

	/* getLoanAccountsByAccountNo method is for getting particular LoanAccount */
	
	@Override
	public LoanAccount getLoanAccountsByAccountNo(int accountNo) {
		LoanAccount loanAccount=null;
		Iterator<LoanAccount> iterator = loanAccountList.iterator();
		while(iterator.hasNext()){
			LoanAccount lAccount=iterator.next();
              if(lAccount.getAccountNo()==accountNo){
				
            	  loanAccount = lAccount;
			}
			
			
		}
			
		
		return loanAccount;
	}

	/* deleteLoanAccount method is for deleting particular LoanAccount */
	@Override
	public void deleteLoanAccount(int accountNo) {
		LoanAccount loanAccount=null;
		Iterator<LoanAccount> iterator = loanAccountList.iterator();
		while(iterator.hasNext()){
			LoanAccount lAccount=iterator.next();
              if(lAccount.getAccountNo()==accountNo){
				
            	  loanAccount = lAccount;
			}
			
			
		}
			
		
		loanAccountList.remove(loanAccount);
		
	}

}
