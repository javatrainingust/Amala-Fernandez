/***
 * LoanAccountDao 
 * LoanAccountDao is an interface
 *  06-10-2020
 * */

package com.training.dao;

import java.util.List;

import com.ust.model.CurrentAccount;
import com.ust.model.LoanAccount;
/*** 
 * LoanAccountDao is an interface
 * */
public interface LoanAccountDao {
	
	/* getAllLoanAccounts method is for getting all the LoanAccount */
	
public List<LoanAccount> getAllLoanAccounts();

/* getLoanAccountsByAccountNo method is for getting particular LoanAccount */

	public LoanAccount getLoanAccountsByAccountNo(int accountNo);
	
	/* deleteLoanAccount method is for deleting particular LoanAccount */
	
	public void deleteLoanAccount(int accountNo);
}
