/***
 * CurrentAccount 
 * class extends Account class
 * 30-09-2020
 * */
package com.ust.model;
/***
 * CurrentAccount 
 * class extends Account class
 * */
public class CurrentAccount extends Account implements Comparable<CurrentAccount> {
    
    float OverDraftLimit;
     float balance;
     /***
 	 * CurrentAccount class default constructor
 	 * */
    public CurrentAccount(){
    	System.out.println("inside CurrentAccount default constructor");
    }  
    
    /***
	 * Account class parameterised constructor
	 * */
    public CurrentAccount(int accountNo, String accountHolderName,float balance,float OverDraftLimit) {
		super(accountNo,accountHolderName,balance);
		this.balance = balance;
		this.OverDraftLimit=OverDraftLimit;
		System.out.println("inside CurrentAccount parameterised constructor");
	}


  /* CheckOverDraft is for checking overdraft amount */
    
	public float getBalance() {
		return balance;
	}


	public String CheckOverDraft(float balance)
    {
    /*condition check */
    if(balance>=50000)
    {
          return "Overdraft limit is 25000 as balance is above 50000";
    }
    
    else if(balance >25000 && balance <50000)
    	return "Overdraft limit is 15000 as balance is between 25000 and 50000";
    
    else
    	return "Overdraft limit is 5000 as balance is below 25000";

    }


	public float getOverDraftLimit() {
		return OverDraftLimit;
	}


	@Override
	public int compareTo(CurrentAccount currentAccount) {
		
		return this.accountHolderName.compareTo(currentAccount.getAccountHolderName());
	}
}

