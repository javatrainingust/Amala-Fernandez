/***
 * Account 
 * class is having private variables and setters and getters for private variables.
 * 30-09-2020
 * */
package com.ust.model;

/***
 * class is having private variables and setters and getters for private variables.
 * */

import com.ust.util.ICalculator;
import com.ust.util.IntrestCalculation;

public class Account {
	private int accountNo;
	protected String accountHolderName;
	private float balance;
	/***
	 *Account class default constructor
	 * */
	public Account() {
		System.out.println("inside account default constructor");
	}
	/***
	 * Account class parameterised constructor
	 * */
	public Account(int accountNo, String accountHolderName,float balance) {
		super();
		this.accountNo = accountNo;
		this.accountHolderName = accountHolderName;
		this.balance=balance;
	//	System.out.println("inside account parameterised constructor");
	}

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public float getBalance() {
		return balance;
	}

	// IntrestCalculation interest=new IntrestCalculation();

	/* interestCalculation for calculating interest */

	public void interestCalculation(float amount, ICalculator interest) {
		float fdinterest = interest.calculateInterest(amount);
		System.out.println("Account interest" + fdinterest);
	}

}