/*
 * Instrument
 * Instrument is an interface having a method perform.
 * 13-10-2020
 */

package com.ust.training.java;
/*
 * Instrument is an interface having a method perform.
 */
public interface Instrument {
	/*
	 * implementation method
	 */
	public void play();
}
