/*
 * PerformanceDemo
 * PerformanceDemo is a class and includes loading the definitions from the given XML file.
 * 13-10-2020
 */
package com.ust.training.java;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;
/*
 * PerformanceDemo is a class and includes loading the definitions from the given XML file.
 */
public class PerformanceDemo {
	@Autowired
	InstrumentList instrumentList;
	
	/*
	 * Main method
	 */
	public static void main(String[] args) {
		
		// loading the definitions from the given XML file
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		 
		InstrumentList instrumentListOne =  context.getBean("instrumentList",InstrumentList.class);
		instrumentListOne.perform();

	}

}
