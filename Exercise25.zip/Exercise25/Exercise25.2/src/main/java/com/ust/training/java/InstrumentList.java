/*
 * InstrumentaList
 * InstrumentaList is a class which implements Performer
 * 13-10-2020
 */

package com.ust.training.java;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
/*
 * InstrumentaList is a class which implements Performer
 */
@Component
public class InstrumentList implements Performer{
	
@Autowired
	Saxophone saxophone;

/*
 * implementation method
 */
public void perform() {
	saxophone.play();
}
}
