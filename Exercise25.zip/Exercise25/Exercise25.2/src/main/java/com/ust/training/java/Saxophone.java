/*
 * Saxophone
 * Saxophone is a class which implements Instrument
 * 13-10-2020
 */
package com.ust.training.java;

import org.springframework.stereotype.Component;
/*
 * Saxophone is a class which implements Instrument
 */
@Component 
public class Saxophone implements Instrument {
	/*
	 * implementation method
	 */
	public void play() {
		System.out.println("saxophone is playing");
		
	}

}
