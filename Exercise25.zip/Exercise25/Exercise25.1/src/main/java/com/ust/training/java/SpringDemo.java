/*
 * SpringDemo
 * SpringDemo is a class and includes loading the definitions from the given XML file.
 * 13-10-2020
 */

package com.ust.training.java;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

/*
 * SpringDemo is a class and includes loading the definitions from the given XML file.
 */
@Component
public class SpringDemo {

	@Autowired
	Organizer organizer;
	
	/*
	 * Main method
	 */
	public static void main(String[] args) {
	
		// loading the definitions from the given XML file
				ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
				 
				Organizer organizerOne =  context.getBean("organizer",Organizer.class);
				organizerOne.sayGreetings();
		
		
	}

}
