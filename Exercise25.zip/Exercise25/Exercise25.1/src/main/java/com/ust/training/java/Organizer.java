/*
 * Organizer
 * Organizer is a class having a method sayGreetings.
 * 13-10-2020
 */

package com.ust.training.java;

import org.springframework.stereotype.Component;

/*
 * Organizer is a class having a method sayGreetings.
 */
@Component
public class Organizer {
	
	/*
	 * sayGreetings is a method,which displays greetings 
	 */
public void sayGreetings() {
	System.out.println("Welcome to the talent competion");
}
	
}
