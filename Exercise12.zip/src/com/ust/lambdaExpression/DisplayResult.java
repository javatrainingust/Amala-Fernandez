package com.ust.lambdaExpression;

/***
 * DisplayResult 
 * DisplayResult is an interface and includes a method display
 * 01-10-2020
 * */
public interface DisplayResult {
	public void display(String s);
	
	
}


