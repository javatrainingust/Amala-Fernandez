package com.ust.lambdaExpression;
/***
 * CheckValue 
 * CheckValue is an interface and includes a method check
 * 01-10-2020
 * */
public interface CheckValue {
	public boolean check(int n);
}
