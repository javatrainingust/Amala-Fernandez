package com.ust.lambdaExpression;
/***
 * NumCalculator 
 * NumCalculator is an interface and includes a method getValue
 * 01-10-2020
 * */
public interface NumCalculator {
	public int getValue(int a,int b);
	
}
