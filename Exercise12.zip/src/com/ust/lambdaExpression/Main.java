package com.ust.lambdaExpression;
/***
 * Main 
 * Main is class and includes method implementation and invoke
 * 01-10-2020
 * */
public class Main {

	public static void main(String[] args) {
		/*Lamda expression for checking given no is odd or even */
		CheckValue iseven = (n)->(n%2)==0;
		if(iseven.check(10))System.out.println("Number is even number");
		else System.out.println("Number is odd number");
		
		/*Lamda expression for checking for adding two numbers */
		
		NumCalculator add=(a,b)->(a+b);
		System.out.println(add.getValue(10, 20));
		
		/*Lamda expression for displaying given string */
		
		DisplayResult myName=(s)-> System.out.println(s);
		myName.display("Amala");
		
		
		/*Lamda expression for displaying a string */
		
		Test test=()->(System.out.println("LamdaExpression"));
		test.test();
	}

}
