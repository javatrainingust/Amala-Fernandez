package com.ust.lambdaExpression;
/***
 * Test 
 * Test is an interface and includes a method test
 * 01-10-2020
 * */
public interface Test {
public void test();

}
