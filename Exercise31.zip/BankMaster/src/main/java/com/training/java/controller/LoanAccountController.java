
/*
 * LoanAccountController
 * LoanAccountController is acontroller class having a method .
 * 15-10-2020
 */
package com.training.java.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.training.java.service.FDAccountService;
import com.training.java.service.LoanAccountDaoService;
import com.ust.java.model.FDAccount;
import com.ust.java.model.LoanAccount;

/*
 * LoanAccountController is acontroller class having a method.
 */
@Controller
public class LoanAccountController {
	@Autowired
	private	LoanAccountDaoService loanAccountService;
	
	/*
	 * getAllLoanAccounts is  a method which returns view name .
	 */	
	@RequestMapping("/loan")
	public String getAllLoanAccounts(Model model){
		System.out.println("Inside LoanAccountController ");
		List<LoanAccount> loanAccountListList = loanAccountService.getAllLoanAccounts();
		
		model.addAttribute("key",loanAccountListList );
		
		
		return "loanAccountList";
}}
