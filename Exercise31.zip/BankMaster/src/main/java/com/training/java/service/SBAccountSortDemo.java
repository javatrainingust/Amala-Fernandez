/***
 * SBAccountSortDemo 
 * SBAccountSortDemo is  class for displaying details
 * 07-10-2020
 * */
package com.training.java.service;
/***
 * SBAccountSortDemo 
 * SBAccountSortDemo is  class for displaying details
 * 07-10-2020
 * */
public class SBAccountSortDemo {
	/***
	 * main method
	 * */
	public static void main(String[] args) {
		
		SBAccountService sbAccountService=new SBAccountService();
		sbAccountService.getAllSBAccounts();
			System.out.println("----------------------");
			System.out.println();
			System.out.println("displaying all SBAccount after sorting");
			sbAccountService.getAllSBAccountsSortedByNames();
			System.out.println("----------------------");
			System.out.println();
			System.out.println("displaying all SBAccount based on salary");
			sbAccountService.getAllSBAccountsSortedByBalance();
}

}
