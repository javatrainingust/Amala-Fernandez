/*
 * CurrentAccountController
 * CurrentAccountController is acontroller class having a method .
 * 15-10-2020
 */

package com.training.java.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.training.java.dao.CurrentAccountDao;
import com.training.java.service.CurrentAccountService;
import com.ust.java.model.CurrentAccount;

/*
 * CurrentAccountController is acontroller class having a method .
 */

@Controller
public class CurrentAccountController {
	
	@Autowired
	private	CurrentAccountService currentAccountService;
	
	/*
	 * getAllCurrentAccounts is  a method which returns view name .
	 */	
	
	@RequestMapping("/current")
	public String getAllCurrentAccounts(Model model){
		System.out.println("Inside CurrentAccountController getAllCurrentAccounts");
		List<CurrentAccount> currentAccountListList = currentAccountService.getAllCurrentAccounts();
		
		model.addAttribute("key",currentAccountListList );
		
		
		return "currentAccountList";
	}
	}
	

