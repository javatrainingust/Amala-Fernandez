
/*
 * LoanAccountController
 * LoanAccountController is acontroller class having a method .
 * 15-10-2020
 */
package com.training.java.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.training.java.service.FDAccountService;
import com.training.java.service.LoanAccountDaoService;
import com.ust.java.model.FDAccount;
import com.ust.java.model.LoanAccount;

/*
 * LoanAccountController is acontroller class having a method.
 */
@Controller
public class LoanAccountController {
	@Autowired
	private LoanAccountDaoService loanAccountService;

	/*
	 * showForm is a method to show LoanAccount form .
	 */
	@RequestMapping("/showLoanAccountForm")
	public String showForm(Model model) {
		LoanAccount lAccount = new LoanAccount();
		model.addAttribute("key", lAccount);

		return "addLoanAccount";

	}

	/*
	 * addLoanAccount is a method to add currentAccount .
	 * 
	 * @param lAccount
	 */
	@RequestMapping("/addLoanAccount")
	public String addLoanAccount(@ModelAttribute("loanAccount") LoanAccount lAccount) {

		loanAccountService.addLoanAccounts(lAccount);

		return "redirect:/loan";

	}

	/*
	 * getAllLoanAccounts is a method which returns view name .
	 */
	@RequestMapping("/loan")
	public String getAllLoanAccounts(Model model) {
		System.out.println("Inside LoanAccountController ");
		List<LoanAccount> loanAccountListList = loanAccountService.getAllLoanAccounts();

		model.addAttribute("key", loanAccountListList);

		return "loanAccountList";
	}

	/*
	 * getAllCurrentAccountsSortedByNames is a method which returns view name .
	 */
	@RequestMapping("/loanAccountsByNames")
	public String getAllLoanAccountsSortedByNames(Model model) {
		System.out.println("Inside LoanAccountController ");
		List<LoanAccount> loanAccountListList = loanAccountService.getAllLoanAccountsSortedByNames();

		model.addAttribute("key", loanAccountListList);

		return "redirect:/loan";
	}

	/*
	 * getAllCurrentAccountsSortedByOutStandingAmount is a method which returns view
	 * name .
	 */
	@RequestMapping("/loanAccountsByOutStandingAmount")
	public String getAllCurrentAccountsSortedByOutStandingAmount(Model model) {
		System.out.println("Inside LoanAccountController ");
		List<LoanAccount> loanAccountListList = loanAccountService.getAllLoanAccountsSortedByOutStandingAmount();

		model.addAttribute("key", loanAccountListList);

		return "redirect:/loan";
	}

	/*
	 * getloanAccount is a method to dispaly particular account details .
	 */
	@RequestMapping("/viewLoanAccount")
	public String getLoanAccount(@RequestParam("accNo") String accNo, Model model) {

		LoanAccount loanAccount = loanAccountService.getLoanAccountsByAccountNo(Integer.parseInt(accNo));

		model.addAttribute("key", loanAccount);

		return "viewLoanAccount";

	}

	/*
	 * deleteLoanAccount is a method to delete particular account details .
	 */
	@RequestMapping("/deleteLoanAccount")
	public String deleteLoanAccount(@RequestParam("accNo") String accNo, Model model) {

		loanAccountService.deleteLoanAccount(Integer.parseInt(accNo));

		return "redirect:/loan";

	}

	/*
	 * updateLoanAccount is a method to update currentAccount .
	 * 
	 * @param lAccount
	 */
	@RequestMapping("/updateLoanAccount")
	public String updateLoanAccount(@ModelAttribute("loanAccount") LoanAccount lAccount) {

		loanAccountService.updateLoanAccounts(lAccount);

		return "redirect:/loan";

	}
}
