package com.ust.java.util;

import static org.junit.Assert.*;

import org.junit.Test;

import com.ust.java.model.SBAccount;

/**
 * 
 *  IntrestCalculationTest 
 *  IntrestCalculationTest class is for testing IntrestCalculation class
 *  01-10-2020
 * */
public class IntrestCalculationTest {

	/* Test method for IntrestCalculation  */
	@Test
	public void testCalculateInterestFloat() {
		
		float expectedValue=7.00f;
		IntrestCalculation intrestCalculation=new IntrestCalculation();
		float actualValue= intrestCalculation.calculateInterest(1000);
		assertEquals(expectedValue,actualValue,0.0f);
	}
	/* Test method for IntrestCalculation */
	@Test
	public void testCalculateInterestFloatFloat() {
		float expectedValue=5.00f;
		IntrestCalculation intrestCalculation=new IntrestCalculation();
		float actualValue= intrestCalculation.calculateInterest(1000,1);
		assertEquals(expectedValue,actualValue,0.00f);
	}

}
