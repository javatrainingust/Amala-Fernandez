package com.ust.generic.service;

import com.ust.model.Account;
import com.ust.model.FDAccount;
import com.ust.model.SBAccount;
import com.ust.util.IntrestCalculation;

public class GenericService {

	public static void main(String[] args) {
		

		FDAccount fd=new FDAccount();
		fd.setAccountNo(1000);
		fd.setAccountHolderName("Amala");
		
		SBAccount sb=new SBAccount();
		sb.setAccountNo(1001);
		sb.setAccountHolderName("Fernandez");
		
		Account[] account={new Account(),fd,sb};
		
		
		IntrestCalculation calculator=new IntrestCalculation();
		
		for(Account accounts:account){
			
			accounts.interestCalculation(10000, calculator);
			if(accounts instanceof FDAccount ){
				
				FDAccount fdAccount=(FDAccount) accounts;
				fdAccount.autoRenewal(6);
			}
		}
	}

}
