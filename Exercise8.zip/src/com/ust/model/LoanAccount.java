package com.ust.model;

public class LoanAccount extends Account{

    int tenure=12;
    float loanOutstanding;

    public void CalculateEmi(float loanTaken)
    {
          float emi= loanTaken/tenure;
          loanOutstanding=loanTaken-emi;
          System.out.println("Emi " +loanTaken +" is: " +emi);
          System.out.println("Loan Outstanding Amount: " +loanOutstanding);
    }

	

}

