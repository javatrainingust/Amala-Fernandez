package com.ust.model;

public class CurrentAccount extends Account {
    
    float OverDraftLimit;
    private float balance=50000;
    
    public void CheckOverDraft()
    {
    
    if(balance>=50000)
    {
          System.out.println("Overdraft limit is 25000 as balance is above 50000");
    }
    
    else if(balance >25000 && balance <50000)
          System.out.println("Overdraft limit is 15000 as balance is between 25000 and 50000");
    
    else
          System.out.println("Overdraft limit is 5000 as balance is below 25000");

    }
}

