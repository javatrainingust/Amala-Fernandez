package com.ust.model;

/**
 * SBAccount class extends Account class.Which has 2 methods, withdrawMoney for withdrawing money and interestCalculation for calculating interest
 */

import com.ust.util.ICalculator;
import com.ust.util.IntrestCalculation;

public class SBAccount extends Account {

	private float balance=50000;
	 float duration=1;
	IntrestCalculation interest=new IntrestCalculation();
	
    /*withdrawMoney for withdrawing money and take one argument */
	
    public void withdrawMoney(float amountWithdrawn)
    {
          balance=balance- amountWithdrawn;
          System.out.println("Account balance after withdrawing is :" +balance);
    }
    /*interestCalculation for calculating interest and take two argument */
    public void interestCalculation(float amount,ICalculator interest){
    	
		float sbinterest=interest.calculateInterest( amount,duration);
    	System.out.println("savings bank interest"+sbinterest);
    	}
}

