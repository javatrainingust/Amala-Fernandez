/*
 * CountryDetailsController
 * CountryDetailsController is a controller class.
 * 22-10-2020
 */

package com.ust.rest.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ust.rest.model.CountryDetails;
/*
 * CountryDetailsController is a controller class.
 */
@RestController
public class CountryDetailsController {

	Map<String,CountryDetails> countryDatabase=  new HashMap<String,CountryDetails>();
	
	
	
	/*
	 * getDummyCountry is a method to get countryDetails
	 */
	@RequestMapping(value="/countryDetails/dummy",method=RequestMethod.GET) 
	public CountryDetails getDummyCountry() {
		
		CountryDetails countryDetails = new CountryDetails();
		
		countryDetails.setCode("IN");;
		countryDetails.setDescription("This is India");
		countryDetails.setMessage("Dummy countrydetails created");
		
		countryDatabase.put("IN", countryDetails);
		
		return countryDetails;	
		
		
		
	}
	
	/*
	 * createCountryDetails is a method to create countryDetails
	 */
	
	@RequestMapping(value="/countryDetails",method=RequestMethod.POST) 
	public CountryDetails createCountryDetails(@RequestBody CountryDetails country) {
		
		System.out.println("Country code : "+ country.getCode());
		if(countryDatabase.containsKey(country.getCode())) {
			
			country.setMessage("Country already exist");
			
		}
		else {
			
			countryDatabase.put(country.getCode(), country);
			country.setMessage("Country created");
			
		}
				
		return country;
		
	}
	
	/*
	 * getAllCountryDetails is a method to get all countryDetails
	 */
	
	@RequestMapping(value="/countryDetails",method=RequestMethod.GET) 
	public List<CountryDetails> getAllCountryDetails() {
		
		List<CountryDetails> CountryDetailss  = new ArrayList<CountryDetails>();
		
		Set<String> countryCodeKeys = countryDatabase.keySet();
		
		for(String countryCode: countryCodeKeys) {
			
			CountryDetailss.add(countryDatabase.get(countryCode));
		}
			
		
		return CountryDetailss;	
		
		
		
	}
	
	/*
	 * getCountryDetailsByCode is a method to get specefic countryDetails
	 */
	
	
	@RequestMapping(value="/countryDetails/{code}",method=RequestMethod.GET) 
	public CountryDetails getCountryDetailsByCode(@PathVariable String code) {
		
			
		return countryDatabase.get(code);
	}
	

	/*
	 * deleteCountryDetails is a method to delete specefic countryDetails
	 */
	@RequestMapping(value="/countryDetails/{code}",method=RequestMethod.DELETE)
	public CountryDetails deleteCountryDetails(@PathVariable String code) {
		
		CountryDetails  countryDetails = new CountryDetails();
		
		if(countryDatabase.containsKey(code)) {
			countryDetails = countryDatabase.get(code);
			
			countryDatabase.remove(code);
			
			countryDetails.setMessage("country deleted");
			
		}
		else {
			
			countryDetails.setMessage("country not found");
			
		}
				
		return countryDetails;
		
		
		
	}
	
	/*
	 * updateCountryDetails is a method to update specefic countryDetails
	 */
	
	@RequestMapping(value="/countryDetails/{code}",method=RequestMethod.PUT)
	public CountryDetails updateCountryDetails(@PathVariable String code,@RequestBody CountryDetails modifiedCountryDetails ) {
		
		CountryDetails  countryDetails = new CountryDetails();
		if(countryDatabase.containsKey(code)) {
			
			countryDetails = countryDatabase.get(code);
			countryDetails.setDescription(modifiedCountryDetails.getDescription());
			
			countryDetails.setMessage("Employee updated");
			
		}
		else {
			countryDetails.setMessage("Employee not found");
			
		}
				
		return countryDetails;
	}
	
}
