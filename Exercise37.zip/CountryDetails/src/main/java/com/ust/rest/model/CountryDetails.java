/*
 * CountryDetails
 * CountryDetails is a model class.
 * 22-10-2020
 */


package com.ust.rest.model;

/*
 * CountryDetails is a model class.
 */
public class CountryDetails {
	
	 String code;
	 String description;
	String message;
	
	/*
	 * getter method for message
	 */
	
	public String getMessage() {
		return message;
	}
	
	/*
	 * setter method for message
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	
	/*
	 * getter method for code
	 */
	public String getCode() {
		return code;
	}
	/*
	 * setter method for code
	 */
	public void setCode(String code) {
		this.code = code;
	}
	/*
	 * getter method for description
	 */
	public String getDescription() {
		return description;
	}
	
	/*
	 * setter method for description
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	

}
