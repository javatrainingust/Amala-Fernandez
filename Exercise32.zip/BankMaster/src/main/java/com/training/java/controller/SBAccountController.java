/*
 * SBAccountController
 * SBAccountController is acontroller class having a method .
 * 15-10-2020
 */

package com.training.java.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.training.java.service.LoanAccountDaoService;
import com.training.java.service.SBAccountService;
import com.ust.java.model.LoanAccount;
import com.ust.java.model.SBAccount;

/*
 * SBAccountController is a controller class having a method .
 */
@Controller

public class SBAccountController {
	@Autowired
	private	SBAccountService sbAccountService;
	
	/*
	 * getAllSbAccounts is  a method which returns view name .
	 */	
	@RequestMapping("/sb")
	public String getAllSbAccounts(Model model){
		System.out.println("Inside SBAccountController ");
		List<SBAccount> sbAccountListList = sbAccountService.getAllSBAccounts();
		
		model.addAttribute("key",sbAccountListList );
		
		
		return "sbAccountList";
}
	/*
	 * getFdAccount is  a method to dispaly particular account details .
	 */	
	@RequestMapping("/viewSbAccount")
	public String getSbAccount(@RequestParam("accNo")String accNo,Model model) {
		
		
		SBAccount sbAccount = sbAccountService.getSBAccountsByAccountNo(Integer.parseInt(accNo));
		
		model.addAttribute("key", sbAccount);
		
		
		return "viewSbAccount";
		
}	

}
