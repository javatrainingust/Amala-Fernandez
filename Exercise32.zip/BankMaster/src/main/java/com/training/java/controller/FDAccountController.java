/*
 * FDAccountController
 * FDAccountController  is a controller class having a method .
 * 15-10-2020
 */

package com.training.java.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.training.java.service.CurrentAccountService;
import com.training.java.service.FDAccountService;
import com.ust.java.model.CurrentAccount;
import com.ust.java.model.FDAccount;
/*
 * FDAccountController  is a controller class having a method .
 */
@Controller
public class FDAccountController {

	@Autowired
	private	FDAccountService fdAccountService;
	
	/*
	 * getAllFdAccounts is  a method which returns view name .
	 */	
	@RequestMapping("/fd")
	public String getAllFdAccounts(Model model){
		System.out.println("Inside FDAccountController ");
		List<FDAccount> fdAccountListList = fdAccountService.getAllFDAccounts();
		
		model.addAttribute("key",fdAccountListList );
		
		
		return "fdAccountList";
	}
	

	/*
	 * getCurrentAccount is  a method to dispaly particular account details .
	 */	
	@RequestMapping("/viewFdAccount")
	public String getFdAccount(@RequestParam("accNo")String accNo,Model model) {
		
		
		FDAccount fdAccount = fdAccountService.getFDAccountsByAccountNo(Integer.parseInt(accNo));
		
		model.addAttribute("key", fdAccount);
		
		
		return "viewFdAccount";
		
		
	}
}
