/*
 * InsufficientBalanceException
 * InsufficientBalanceException is a class that extends Exception
 * 09-10-2020
 */


package com.training.java.bankingapplicationmaster.exception;
/*
 * InsufficientBalanceException is a class that extends Exception
 */

public class InsufficientBalanceException extends Exception {

	float balance;
	
	/*
	 * InsufficientBalanceException is a class constructor
	 */
	public InsufficientBalanceException(float balance){
		this.balance=balance;
	}

	/*tostring method*/
	@Override
	public String toString() {
		return "InsufficientBalanceException [balance=" + balance + "]";
	}
	
	
}
