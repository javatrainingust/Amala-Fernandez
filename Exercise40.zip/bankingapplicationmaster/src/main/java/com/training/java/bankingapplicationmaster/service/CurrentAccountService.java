/***
 * CurrentAccountService 
 * CurrentAccountService is  class for displaying details
 * 06-10-2020
 * */

package com.training.java.bankingapplicationmaster.service;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.java.bankingapplicationmaster.dao.CurrentAccountDao;
import com.training.java.bankingapplicationmaster.dao.CurrentAccountDaoImpl;
import com.training.java.bankingapplicationmaster.model.CurrentAccount;
import com.training.java.bankingapplicationmaster.model.FDAccount;

/***
 * CurrentAccountService is class for displaying details
 */

@Service
public class CurrentAccountService {
	@Autowired
	private CurrentAccountDao currentAccountDaoImpl;

	/***
	 * CurrentAccountService class constructor
	 */
	public CurrentAccountService() {

	}

	/*
	 * for dispalying all the CurrentAccount
	 */

	public List<CurrentAccount> getAllCurrentAccounts() {
		List currentAccountList = currentAccountDaoImpl.getAllCurrentAccounts();

		System.out.println("Inside CurrentAccountService getAllCurrentAccounts");
		/*
		 * Iterator<CurrentAccount> iterator = currentAccountList.iterator();
		 * while(iterator.hasNext()){ CurrentAccount currentAccount=iterator.next();
		 * 
		 * System.out.println("Account No "+currentAccount.getAccountNo());
		 * System.out.println("Account Holder Name"+currentAccount.getAccountHolderName(
		 * )); System.out.println("balance "+currentAccount.getBalance()); }
		 */
		return currentAccountList;
	}

	/*
	 * for displaying particular CurrentAccount
	 */

	public CurrentAccount getCurrentAccountsByAccountNo(int accountNo) {
		CurrentAccount currentAccount = currentAccountDaoImpl.getCurrentAccountsByAccountNo(accountNo);
		System.out.println("Account No " + currentAccount.getAccountNo());
		System.out.println("Account Holder Name" + currentAccount.getAccountHolderName());
		System.out.println("balance " + currentAccount.getBalance());
		return currentAccount;
	}

	/*
	 * for deleting particular CurrentAccount
	 */

	public void deleteCurrentAccount(int accountNo) {

		currentAccountDaoImpl.deleteCurrentAccount(accountNo);
	}

	/*
	 * for getting all accounts sorted by names
	 */

	public List<CurrentAccount> getAllCurrentAccountsSortedByNames() {

		List<CurrentAccount> currentAccountList = currentAccountDaoImpl.getAllCurrentAccounts();

		Collections.sort(currentAccountList);

		/*
		 * Creating stream and sorting
		 * 
		 * Stream<CurrentAccount> currentAccountStream = currentAccountList.stream();
		 * 
		 * Stream<CurrentAccount> sortedStream = currentAccountStream.sorted();
		 * 
		 * List sortedCurrentAccountList = sortedStream.collect(Collectors.toList());
		 * 
		 * 
		 * Iterator<CurrentAccount> iterator = sortedCurrentAccountList.iterator();
		 * 
		 * while (iterator.hasNext()) {
		 * 
		 * CurrentAccount currentAccount = iterator.next();
		 * 
		 * System.out.println("Account No " + currentAccount.getAccountNo());
		 * System.out.println("Account Holder Name" +
		 * currentAccount.getAccountHolderName()); System.out.println("balance " +
		 * currentAccount.getBalance());
		 * 
		 * }
		 */
		return currentAccountList;
	}

	/*
	 * for getting all accounts sorted by over draft limit
	 */

	public List<CurrentAccount> getAllCurrentAccountsSortedByOverDraftLimit() {

		List<CurrentAccount> currentAccountList = currentAccountDaoImpl.getAllCurrentAccounts();

		Collections.sort(currentAccountList, new CurrentOverDraftComparator());

		/*
		 * Creating stream and sorting
		 * 
		 * Stream<CurrentAccount> currentAccountStream = currentAccountList.stream();
		 * 
		 * Stream<CurrentAccount> sortedStream = currentAccountStream.sorted(new
		 * CurrentOverDraftComparator());
		 * 
		 * List sortedCurrentAccountList = sortedStream.collect(Collectors.toList());
		 * 
		 * Iterator<CurrentAccount> iterator = sortedCurrentAccountList.iterator();
		 * 
		 * 
		 * while (iterator.hasNext()) {
		 * 
		 * CurrentAccount currentAccount = iterator.next();
		 * 
		 * System.out.println("Account No " + currentAccount.getAccountNo());
		 * System.out.println("Account Holder Name" +
		 * currentAccount.getAccountHolderName()); System.out.println("balance " +
		 * currentAccount.getBalance()); System.out.println("over draft limit " +
		 * currentAccount.getOverDraftLimit()); }
		 */

		return currentAccountList;
	}

	/*
	 * method is for adding currentAccount
	 */

	public boolean addCurrentAccounts(CurrentAccount currentAccount) {
		boolean isAdded = currentAccountDaoImpl.addCurrentAccounts(currentAccount);

		if (!isAdded) {
			System.out.println("current Account already exist");
			return false;
		} else {
			System.out.println("current Account successfully added");

			return true;
		}

	}

	/*
	 * method is for updating FDAccounts details
	 */

	public boolean updateCurrentAccounts(CurrentAccount currentAccount) {

		if (currentAccountDaoImpl.updateCurrentAccounts(currentAccount)) {
			return true;
		} else {
			System.out.println("current Account successfully added");

			return false;
		}
	}
}