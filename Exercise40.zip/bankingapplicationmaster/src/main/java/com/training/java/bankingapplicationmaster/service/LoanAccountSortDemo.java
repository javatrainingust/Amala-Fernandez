/***
 * LoanAccountSortDemo 
 * LoanAccountSortDemo is  class for dispalying details
 * 07-10-2020
 * */
package com.training.java.bankingapplicationmaster.service;
/***
 * LoanAccountSortDemo is  class for dispalying details
 * */
public class LoanAccountSortDemo {
	/***
	 * main method
	 * */
	public static void main(String[] args) {
		LoanAccountDaoService loanAccountService=new LoanAccountDaoService();
		loanAccountService.getAllLoanAccounts();
			System.out.println("----------------------");
			System.out.println();
			System.out.println("displaying all LoanAccounts after sorting");
			loanAccountService.getAllLoanAccountsSortedByNames();
			System.out.println("----------------------");
			System.out.println();
			System.out.println("displaying all LoanAccounts based on Loan outstanding amount");
			loanAccountService.getAllLoanAccountsSortedByOutStandingAmount();

	}

}
