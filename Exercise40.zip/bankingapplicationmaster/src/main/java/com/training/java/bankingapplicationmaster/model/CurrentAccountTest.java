/**
 * 
 *  CurrentAccountTest 
 *  CurrentAccountTest class is for testing CurrentAccount class
 *  01-10-2020
 * */
package com.training.java.bankingapplicationmaster.model;

import static org.junit.Assert.*;

import org.junit.Test;
/** 
 *  CurrentAccountTest class is for testing CurrentAccount class
 * */
public class CurrentAccountTest {
	/* 
	 * calculateInterest method for  testAutoRenewal
	  */
	@Test
	public void testCheckOverDraft() {
		
		String expectedValue= "Overdraft limit is 25000 as balance is above 50000";
		CurrentAccount ca= new CurrentAccount();
		String actualValue=ca.CheckOverDraft(90000);
		assertEquals(expectedValue,actualValue);
	}

}
