/*
 * FDAccountController
 * FDAccountController  is a controller class having a method .
 * 15-10-2020
 */

package com.training.java.bankingapplicationmaster.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.training.java.bankingapplicationmaster.model.CurrentAccount;
import com.training.java.bankingapplicationmaster.model.FDAccount;
import com.training.java.bankingapplicationmaster.service.CurrentAccountService;
import com.training.java.bankingapplicationmaster.service.FDAccountService;

/*
 * FDAccountController  is a controller class having a method .
 */
@RestController
public class FDAccountController {

	@Autowired
	private FDAccountService fdAccountService;

	/*
	 * showForm is a method to show currentAccount form .
	 */
	/*
	 * @RequestMapping("/showFdAccountForm") public String showForm(Model model) {
	 * FDAccount FAccount = new FDAccount(); model.addAttribute("key", FAccount);
	 * 
	 * return "addFdAccount";
	 * 
	 * }
	 */
	/*
	 * addCurrentAccount is a method to add currentAccount .
	 */
	
	@PostMapping("/fdAccounts")
	
	public FDAccount addFdAccount(@RequestBody  FDAccount fAccount) {

		fdAccountService.addFdAccounts(fAccount);

		return fAccount;

	}

	/*
	 * getAllFdAccounts is a method which returns view name .
	 */
	@GetMapping("/fdAccounts")
	public List<FDAccount> getAllFDAccounts() {
		
		List<FDAccount> fdAccountListList = fdAccountService.getAllFDAccounts();

	

		return fdAccountListList;
	}

	/*
	 * getAllFDAccountsSortedByBalance is a method which returns view name .
	 */
	@RequestMapping("/fdAccountsBybalance")
	public String getAllFDAccountsSortedByBalance(Model model) {
		System.out.println("Inside FDAccountController ");
		List<FDAccount> fdAccountListList = fdAccountService.getAllFDAccountsSortedByBalance();

		model.addAttribute("key", fdAccountListList);

		return "fdAccountList";
	}

	/*
	 * getAllFDAccountsSortedByNames is a method which returns view name .
	 */
	@RequestMapping("/fdAccountsByNames")
	public String getAllFDAccountsSortedByNames(Model model) {
		System.out.println("Inside FDAccountController ");
		List<FDAccount> fdAccountListList = fdAccountService.getAllFDAccountsSortedByNames();

		model.addAttribute("key", fdAccountListList);

		return "fdAccountList";
	}

	/*
	 * getCurrentAccount is a method to dispaly particular account details .
	 */
	@GetMapping(value="/fdAccounts/{accountNo}")
	public FDAccount getFdAccount(@PathVariable int accountNo) {

		FDAccount fdAccount = fdAccountService.getFDAccountsByAccountNo(accountNo);

		

		return fdAccount;

	}

	/*
	 * deleteFdAccount is a method to delete particular account details .
	 */
	@DeleteMapping(value="/fdAccounts/{accountNo}")
	public void deleteFdAccount(@PathVariable int accountNo) {

		fdAccountService.deleteFDAccount(accountNo);

		
	}

	/*
	 * updateFdAccount is a method to update currentAccount .
	 */
	@PutMapping("/fdAccounts/{accountNo}")
	public FDAccount updateFdAccount(@PathVariable int accountNo,@RequestBody FDAccount fAccount) {

		
		FDAccount oldAccount=	fdAccountService.getFDAccountsByAccountNo(accountNo);
		if(oldAccount!=null) {
		fdAccountService.updateFdAccounts(fAccount);
		}
		return fAccount;

	}
}
