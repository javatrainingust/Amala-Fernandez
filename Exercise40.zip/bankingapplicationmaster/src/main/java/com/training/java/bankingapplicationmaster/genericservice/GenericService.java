/*
 * GenericService
 * GenericService is a class that displays sb account details
 * 09-10-2020
 */

package com.training.java.bankingapplicationmaster.genericservice;


import com.training.java.bankingapplicationmaster.exception.InsufficientBalanceException;
import com.training.java.bankingapplicationmaster.model.Account;
import com.training.java.bankingapplicationmaster.model.CurrentAccount;
import com.training.java.bankingapplicationmaster.model.FDAccount;
import com.training.java.bankingapplicationmaster.model.LoanAccount;
import com.training.java.bankingapplicationmaster.model.SBAccount;
import com.training.java.bankingapplicationmaster.util.IntrestCalculation;
/*
 * GenericService is a class that displays sb account details
 */
public class GenericService {

	public static void main(String[] args) {
		

		FDAccount fd=new FDAccount(1002,"Carmel",20000,1);
		//fd.setAccountNo(1000);
		//fd.setAccountHolderName("Amala");
		
		SBAccount sb=new SBAccount(2000,"Amala",10000,1);
		//sb.setAccountNo(1001);
		//sb.setAccountHolderName("Fernandez");
		
		
		
		
		try {
			sb.withdrawMoney(20000);
		} catch (InsufficientBalanceException e) {
			System.out.println("You have "+sb.getBalance()+" balance "+e);
			e.printStackTrace();
		}
		
		LoanAccount la=new LoanAccount(4000,"Amala",1,12000,7000);
		//la.setAccountNo(1001);
		//la.setAccountHolderName("Fernandez");
		
		
		
		
		
		
		
		
		
		
		CurrentAccount ca=new CurrentAccount(3000,"Amala",10000,5000);
		//ca.setAccountNo(1001);
		//ca.setAccountHolderName("Fernandez");
		
		
		Account[] account={new Account(),fd,sb};
		IntrestCalculation calculator=new IntrestCalculation();
		
		for(Account accounts:account){
			
			accounts.interestCalculation(10000, calculator);
			if(accounts instanceof FDAccount ){
				
				FDAccount fdAccount=(FDAccount) accounts;
				fdAccount.autoRenewal(6);
			}
		}
	}

}
