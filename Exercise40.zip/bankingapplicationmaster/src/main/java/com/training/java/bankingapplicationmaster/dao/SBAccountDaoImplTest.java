/***
 * SBAccountDaoImplTest
 * SBAccountDaoImplTest is a test class for SBAccountDaoImpl
 * 06-10-2020
 * */
package com.training.java.bankingapplicationmaster.dao;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.training.java.bankingapplicationmaster.model.SBAccount;

/***
 SBAccountDaoImplTest is a test class for SBAccountDaoImpl 
 * */
public class SBAccountDaoImplTest {

	List expectedList;
	
	/***
	 SBAccountDaoImplTest class constructor
	 * */
	
	public SBAccountDaoImplTest() {
		expectedList = new ArrayList<SBAccount>();
		SBAccount sbAccount1 = new SBAccount(2000, "Anu", 10000, 1);
		SBAccount sbAccount2 = new SBAccount(2001, "Anna", 20000, 2);
		SBAccount sbAccount3 = new SBAccount(2002, "Meenu", 30000, 3);
		SBAccount sbAccount4 = new SBAccount(2003, "Appu", 40000, 4);
		SBAccount sbAccount5 = new SBAccount(2004, "Nia", 50000, 5);

		expectedList.add(sbAccount1);
		expectedList.add(sbAccount2);
		expectedList.add(sbAccount3);
		expectedList.add(sbAccount4);
		expectedList.add(sbAccount5);
	}

	/*
	 * Test method for getAllSBAccounts
	 */
	@Test
	public void testGetAllSBAccounts() {
		SBAccountDaoImpl sbAccountDaoImpl = new SBAccountDaoImpl();
		List actualList = sbAccountDaoImpl.getAllSBAccounts();
		assertEquals(expectedList.size(), actualList.size());
	}

	/*
	 * Test method for getSBAccountsByAccountNo
	 */
	@Test
	public void testGetSBAccountsByAccountNo() {

		String expectedValue = "Appu";
		SBAccountDaoImpl sbAccountDaoImpl = new SBAccountDaoImpl();
		SBAccount actualValue = sbAccountDaoImpl.getSBAccountsByAccountNo(2003);
		assertEquals(expectedValue, actualValue.getAccountHolderName());
	}

	/*
	 * Test method for deleteSBAccount
	 */
	@Test
	public void testDeleteSBAccount() {
		SBAccountDaoImpl sbAccountDaoImpl = new SBAccountDaoImpl();
		sbAccountDaoImpl.deleteSBAccount(2002);
		List actualList = sbAccountDaoImpl.getAllSBAccounts();
		assertEquals(expectedList.size() - 1, actualList.size());
	}

}
