/*
 * CurrentAccountController
 * CurrentAccountController is acontroller class having a method .
 * 15-10-2020
 */

package com.training.java.bankingapplicationmaster.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.training.java.bankingapplicationmaster.dao.CurrentAccountDao;
import com.training.java.bankingapplicationmaster.model.CurrentAccount;
import com.training.java.bankingapplicationmaster.service.CurrentAccountService;

/*
 * CurrentAccountController is acontroller class having a method .
 */

@RestController
public class CurrentAccountController {

	@Autowired
	private CurrentAccountService currentAccountService;

	/*
	 * showForm is a method to show currentAccount form .
	 */
	
	/*
	 * @RequestMapping("/showCurrentAccountForm") public String showForm(Model
	 * model) { CurrentAccount cAccount = new CurrentAccount();
	 * model.addAttribute("key", cAccount);
	 * 
	 * return "addCurrentAccount";
	 * 
	 * }
	 */

	/*
	 * addCurrentAccount is a method to add currentAccount .
	 */
	
	@PostMapping("/currentAccounts")
	
	public CurrentAccount addCurrentAccount(@RequestBody CurrentAccount cAccount) {

		currentAccountService.addCurrentAccounts(cAccount);

		return cAccount ;

	}

	/*
	 * getAllCurrentAccounts is a method which returns view name .
	 */
	@GetMapping("/currentAccounts")
	
	public List<CurrentAccount> getAllCurrentAccounts() {
		
		List<CurrentAccount> currentAccountListList = currentAccountService.getAllCurrentAccounts();

		

		return currentAccountListList;
	}

	/*
	 * getAllCurrentAccountsByNames is a method which returns view name .
	 */

	@RequestMapping("/currentAccountsByNames")
	public String getAllCurrentAccountsByNames(Model model) {
		System.out.println("Inside CurrentAccountController getAllCurrentAccountsByNames");
		List<CurrentAccount> currentAccountListList = currentAccountService.getAllCurrentAccountsSortedByNames();

		model.addAttribute("key", currentAccountListList);

		System.out.println(currentAccountListList);
		return "redirect:/current";
	}
	/*
	 * getAllCurrentAccountsSortedByOverDraftLimit is a method which returns view
	 * name .
	 */

	@RequestMapping("/currentAccountsByOverDraftLimit")
	public String getAllCurrentAccountsSortedByOverDraftLimit(Model model) {
		System.out.println("Inside CurrentAccountController getAllCurrentAccountsSortedByOverDraftLimit");
		List<CurrentAccount> currentAccountListList = currentAccountService
				.getAllCurrentAccountsSortedByOverDraftLimit();

		model.addAttribute("key", currentAccountListList);

		return "redirect:/current";
	}

	/*
	 * getCurrentAccount is a method to dispaly particular account details .
	 */
	@GetMapping("/currentAccounts/{accountNo}")
	
	public CurrentAccount getCurrentAccount(@PathVariable int accountNo) {

		CurrentAccount currentAccount = currentAccountService.getCurrentAccountsByAccountNo(accountNo);

		

		return currentAccount;

	}

	/*
	 * deleteCurrentAccount is a method to delete particular account details .
	 */
	@DeleteMapping("/currentAccounts/{accountNo}")
	public void deleteCurrentAccount(@PathVariable int accountNo) {

		currentAccountService.deleteCurrentAccount(accountNo);

			

	}

	/*
	 * updateCurrentAccount is a method to update currentAccount .
	 */
	@PutMapping("/currentAccounts/{accountNo}")
	public CurrentAccount updateCurrentAccount(@PathVariable int accountNo,@RequestBody CurrentAccount cAccount) {

		CurrentAccount oldAccount=	currentAccountService.getCurrentAccountsByAccountNo(accountNo);
		if(oldAccount!=null) {
				currentAccountService.updateCurrentAccounts(cAccount);

		}
return cAccount;
	}

}
