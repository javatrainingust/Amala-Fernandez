/***
 * FDAccountSortDemo 
 * FDAccountSortDemo is  class for displaying details
 * 07-10-2020
 * */
package com.training.java.bankingapplicationmaster.service;
/***
 * FDAccountSortDemo is  class for displaying details
 * */
public class FDAccountSortDemo {
	/***
	 * main method
	 * */
	public static void main(String[] args) {

System.out.println("displaying all FDAccounts");
		

FDAccountService fdAccountService=new FDAccountService();
    fdAccountService.getAllFDAccounts();
		System.out.println("----------------------");
		System.out.println();
		System.out.println("displaying all FDAccounts after sorting");
		fdAccountService.getAllFDAccountsSortedByNames();
		System.out.println("----------------------");
		System.out.println();
		System.out.println("displaying all FDAccounts based on salary");
		fdAccountService.getAllFDAccountsSortedByBalance();

	}

}
