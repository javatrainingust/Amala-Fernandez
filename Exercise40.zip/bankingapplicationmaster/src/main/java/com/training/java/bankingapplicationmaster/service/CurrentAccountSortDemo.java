/***
 * CurrentAccountServiceTest 
 * CurrentAccountServiceTest is a  class for dispalying details
 * 07-10-2020
 * */

package com.training.java.bankingapplicationmaster.service;
/***
 * CurrentAccountServiceTest is a  class for dispalying details
 * */
public class CurrentAccountSortDemo {

	/***
	 * main method
	 * */
	public static void main(String[] args) {
		
		CurrentAccountService currentAccountService=new CurrentAccountService();
		currentAccountService.getAllCurrentAccounts();
			System.out.println("----------------------");
			System.out.println();
			System.out.println("displaying all FDAccounts after sorting");
			currentAccountService.getAllCurrentAccountsSortedByNames();
			System.out.println("----------------------");
			System.out.println();
			System.out.println("displaying all FDAccounts based on overdraftlimit");
			currentAccountService.getAllCurrentAccountsSortedByOverDraftLimit();
	}

}
