/**
 *  SBAccountTest 
 *  SBAccountTest class is for testing SBAccoun class
 *  01-10-2020
 * */
package com.training.java.bankingapplicationmaster.model;

import static org.junit.Assert.*;

import org.junit.Test;

import com.training.java.bankingapplicationmaster.exception.InsufficientBalanceException;

/**
 *  SBAccountTest class is for testing SBAccoun class
 * */
public class SBAccountTest {

	/*
	 *  Test method for testWithdrawMoney 
	 */
	@Test
	public void testWithdrawMoney() {
		int expectedValue=40000;
		SBAccount sbAccount=new SBAccount();
		try {
			sbAccount.withdrawMoney(10000);
		} catch (InsufficientBalanceException e) {
			
			e.printStackTrace();
		};;
		
		int actualValue=(int) sbAccount.getBalance();
		assertEquals(expectedValue,actualValue);
	}

}
