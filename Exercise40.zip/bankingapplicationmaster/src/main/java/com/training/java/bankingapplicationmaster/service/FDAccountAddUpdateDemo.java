/***
 * FDAccountAddUpdateDemo 
 * FDAccountAddUpdateDemo is class for adding and updating fdaccounts
 * 08-10-2020
 * */

package com.training.java.bankingapplicationmaster.service;

import com.training.java.bankingapplicationmaster.model.FDAccount;
/***
 * FDAccountAddUpdateDemo is class for adding and updating fdaccounts
 * */
public class FDAccountAddUpdateDemo {
	/***
	 * main method
	 * */
	public static void main(String[] args) {
		FDAccountService fdAccountService=new FDAccountService();
		fdAccountService.addFdAccounts(new FDAccount(1000,"Amala",12000,1));
		fdAccountService.addFdAccounts(new FDAccount(1001,"Mary",14000,1));
		fdAccountService.addFdAccounts(new FDAccount(1001,"Mary",14000,1));
		
		System.out.println("Printing all fdaccounts");	
		fdAccountService.getAllFDAccounts();
		
		System.out.println("---------------------------------------------");
		fdAccountService.updateFdAccounts(new FDAccount(1001,"Mary",17000,1));
		
		System.out.println("Printing all updated fdaccounts");	
		fdAccountService.getAllFDAccounts();
	
	}
}
