
/**
 * AccountService
 * In AccountService class invoke the respective methods 
 * 09-10-2020
 */

package com.training.java.bankingapplicationmaster.accountservice;
import com.training.java.bankingapplicationmaster.accountservice.*;
import com.training.java.bankingapplicationmaster.exception.InsufficientBalanceException;
import com.training.java.bankingapplicationmaster.model.Account;
import com.training.java.bankingapplicationmaster.model.CurrentAccount;
import com.training.java.bankingapplicationmaster.model.FDAccount;
import com.training.java.bankingapplicationmaster.model.LoanAccount;
import com.training.java.bankingapplicationmaster.model.SBAccount;
import com.training.java.bankingapplicationmaster.util.IntrestCalculation;


/**
 * In AccountService class invoke the respective methods 
 */

public class AccountService {

	public static void main(String args[]){
	
		
		SBAccount sb= new SBAccount();
		IntrestCalculation calculator=new IntrestCalculation();
        sb.interestCalculation(10000,calculator);
		FDAccount fd= new FDAccount();
		fd.autoRenewal(1);
		fd.interestCalculation(10000,calculator);
		CurrentAccount ca= new CurrentAccount();
		ca.CheckOverDraft(50001);
		
		LoanAccount la= new LoanAccount();
		la.CalculateEmi(200000);
	}

} 
