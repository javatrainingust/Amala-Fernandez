/*
 * BankingapplicationmasterApplication
 * BankingapplicationmasterApplication is a main class
 * 27-10-2020
 * */

package com.training.java.bankingapplicationmaster;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/*
 * BankingapplicationmasterApplication is a main class
 * */
@SpringBootApplication
public class BankingapplicationmasterApplication {

	/*
	 * main method
	 * */
	public static void main(String[] args) {
		SpringApplication.run(BankingapplicationmasterApplication.class, args);
	}

}
