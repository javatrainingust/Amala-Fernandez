package com.training.java.bankingapplicationmaster;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingapplicationmasterApplicationTests {

	@Test
	void contextLoads() {
	}

}
