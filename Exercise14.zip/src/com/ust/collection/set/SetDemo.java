package com.ust.collection.set;

import java.util.HashSet;
import java.util.Set;
/***
 * SetDemo
 * SetDemo class is for creating the hashmap
 * method 05-10-2020
 * */
public class SetDemo {

	public static void main(String[] args) {

		boolean[] cat = new boolean[3];
		
		/*Creating set*/
		
		Set<Cat> cats = new HashSet<Cat>();

		cat[0] = cats.add(new Cat("rosy", 2));

		cat[1] = cats.add(new Cat("pinky", 3));

		cat[2] = cats.add(new Cat("rosy", 2));

		for (int i = 0; i < cat.length; i++) {

			System.out.println("Value inside cat boolean array:" + cat[i]);
		}

		for (Object s : cats) {

			System.out.println("Value inside cat Set:" + s);
		}

	}

	}


