package com.ust.collection.set;

import java.util.HashSet;
import java.util.Set;
/***
 * Exercise1
 * Exercise1 class is for creating the hashset,adding values to it and display set
 * method 05-10-2020
 * */
public class Exercise1 {

	public static void main(String[] args) {
		
    boolean[] b =new boolean[3];
		
		Set set = new HashSet();
		
		b[0] = set.add("test");
		
		b[1] = set.add("work");
		
		b[2] = set.add("test");
		
		for (int i=0; i<b.length; i++) {
			
			System.out.println("Value inside boolean array:"+b[i]);
		}
	
	for(Object o:set) {
		
		System.out.println("Value inside Set:"+o);
	}	

	}

}
