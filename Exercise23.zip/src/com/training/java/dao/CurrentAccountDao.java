/***
 * CurrentAccountDao 
 * CurrentAccountDao is an interface
 *  06-10-2020
 * */

package com.training.java.dao;

import java.util.List;

import com.ust.java.model.CurrentAccount;
import com.ust.java.model.FDAccount;


/***
 * CurrentAccountDao is an interface having abstrsct methods
 * */
public interface CurrentAccountDao {
	
	/* getAllCurrentAccounts method is for getting all the CurrentAccount */
	
public List<CurrentAccount> getAllCurrentAccounts();
	
/* getCurrentAccountsByAccountNo method is for getting particular CurrentAccount */

	public CurrentAccount getCurrentAccountsByAccountNo(int accountNo);
	
	/* deleteCurrentAccount method is for deleting particular CurrentAccount */
	
	public void deleteCurrentAccount(int accountNo);
	
	/*  method is for adding  Current Accounts */
	
	  public boolean addCurrentAccounts(CurrentAccount fdAccount);
	  
	  /* method is for updating  Current Accounts details */
	  
		public boolean updateCurrentAccounts(CurrentAccount fdAccount);
}
