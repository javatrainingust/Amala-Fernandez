/***
 * CurrentAccountServiceTest 
 * CurrentAccountServiceTest is a test class for CurrentAccountService
 * 07-10-2020
 * */

package com.training.java.service;
import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.ust.java.model.CurrentAccount;
/***
 * CurrentAccountServiceTest is  class for displaying details
 * */
public class CurrentAccountServiceTest {

	List<CurrentAccount> currentAccountList;
	CurrentAccountService currentAccountService;

	/** Constructor for CurrentAccountServiceTest */

	public CurrentAccountServiceTest() {
		currentAccountService = new CurrentAccountService();
	

		currentAccountService.addCurrentAccounts(new CurrentAccount(3000,"Amala",10000,5000));
		currentAccountService.addCurrentAccounts(new CurrentAccount(3001,"Mary",25000,15000));
		//System.out.println(currentAccountService.addCurrentAccounts(new CurrentAccount(3000,"Amala",10000,5000)));
			}
	
	
	/** Method  for add account  Success*/
				@Test
		public void testAddCurrentAccountsSuccess() {
					
	assertTrue(currentAccountService.addCurrentAccounts(new CurrentAccount(3002,"Amala",10000,5000)));

			}
				/** Method  for add account  failure*/
		@Test
		public 	void testAddCurrentAccountsFailure() {
		assertFalse(currentAccountService.addCurrentAccounts(new CurrentAccount(3000,"Amala",10000,5000)));
				
		}
		/** Method  for update account  Success*/
		@Test
		public void testUpdateCurrentAccountsSuccess()
		 {
			assertTrue(currentAccountService.updateCurrentAccounts(new CurrentAccount(3000,"Meenu",10000,5000)));
		 }
		
		/** Method  for update account  failure*/
		public void testUpdateCurrentAccountsFailure()
		 {
			assertTrue(currentAccountService.updateCurrentAccounts(new CurrentAccount(3009,"Meenu",10000,5000)));
		 }
	/* for getting all accounts  sorted by names
 
	@Test
	public void testGetAllCurrentAccountsSortedByNames() {
		String expectedValue ="Mary";
		CurrentAccountService currentAccountService=new CurrentAccountService();
		List<CurrentAccount> currentAccountServiceList=currentAccountService.getAllCurrentAccountsSortedByNames();
		String actualValue=currentAccountServiceList.get(3).getAccountHolderName();
		assertEquals(expectedValue,actualValue);
	}
	 for getting all accounts  sorted by over draft limit
	@Test
	public void testGetAllCurrentAccountsSortedByOverDraftLimit() {
		float expectedValue =5000;
		CurrentAccountService currentAccountService=new CurrentAccountService();
		List<CurrentAccount> currentAccountServiceList=currentAccountService.getAllCurrentAccountsSortedByOverDraftLimit();
		float actualValue=currentAccountServiceList.get(0).getOverDraftLimit();
		assertEquals(expectedValue,actualValue,0.0f);
	}*/

}
