/**
 * LoanAccount 
 * LoanAccount class includes LoanAccount details
 *  30-09-2020
 */

package com.ust.java.model;

/**
 * LoanAccount class includes LoanAccount details
 */
public class LoanAccount extends Account implements Comparable<LoanAccount> {

	 int tenure;
	float loanOutstanding;
	private int emi;
	
	

	/***
	 * LoanAccount class default constructor
	 * */

	public LoanAccount() {
		System.out.println("inside LoanAccount default constructor");
	}
	/***
	 * LoanAccount class parameterised constructor
	 * */
	public LoanAccount(int accountNo, String accountHolderName,int tenure,float balance,float loanOutstanding) {
		super(accountNo,accountHolderName,balance);
		this.tenure = tenure;
		this.loanOutstanding=loanOutstanding;
		System.out.println("inside LoanAccount parameterised constructor");

	}

	/*getter method for emi*/
	public int getEmi() {
		return emi;
	}
	
	
	/*getter method for tenure*/
	public int getTenure() {
		return tenure;
	}


	/*getter method for loanOutstanding*/
	public float getLoanOutstanding() {
		return loanOutstanding;
	}


	/*setter method for tenure*/
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	/*setter method for loanOutstanding*/
	public void setLoanOutstanding(float loanOutstanding) {
		this.loanOutstanding = loanOutstanding;
	}
	
	/* CalculateEmi method for calculating EMI */
	public void CalculateEmi(int loanTaken) {
		 emi = loanTaken / tenure;
		loanOutstanding = loanTaken - emi;
		System.out.println("Emi " + loanTaken + " is: " + emi);
		System.out.println("Loan Outstanding Amount: " + loanOutstanding);
	}

	/* compareto method */
	public int compareTo(LoanAccount loanAccount) {
		
		return this.accountHolderName.compareTo(loanAccount.getAccountHolderName());
	}

}
