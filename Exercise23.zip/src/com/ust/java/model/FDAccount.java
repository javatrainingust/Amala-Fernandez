/**
 * FDAccount 
 * FDAccount class includes FDAccount details
 * 30-09-2020
 */
package com.ust.java.model;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.ust.java.util.ICalculator;
import com.ust.java.util.IntrestCalculation;
/**
 * FDAccount class includes FDAccount details
 */
public class FDAccount extends Account implements Renewable,Comparable<FDAccount> {

	private int tenure;
	private boolean	isAutoRenewal;
	public String maturityDate = "28/09-2020";
	
	
	  /***
		 * FDAccount class default constructor
		 * */
	public FDAccount() {
		System.out.println("inside FDAccount default constructor");
	}
	  /***
		 * FDAccount class parameterised constructor
		 * */
	public FDAccount(int accountNo,String accountHolderName,float balance,int tenure) {
		super(accountNo,accountHolderName,balance);
		
		this.tenure = tenure;
	//	System.out.println("inside FDAccount parameterised constructor");
	}
	

	/*getter method for tenure*/
	public int getTenure() {
		return tenure;
	}
	/*setter method for tenure*/
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	/*getter method for isAutoRenewal*/
	public boolean isAutoRenewal() {
		return isAutoRenewal;
	}



	Calendar calendar = Calendar.getInstance();

	// IntrestCalculation interest=new IntrestCalculation();

	/* interestCalculation for calculating interest and take two argument */

	public void interestCalculation(float amount, ICalculator interest) {
		float fdinterest = interest.calculateInterest(amount);
		System.out.println("FD interest" + fdinterest);
	}

	/* autoRenewal method for renewal of FD and take one argument */

	@Override
	public void autoRenewal(int tenure) {
		// TODO Auto-generated method stub

		 isAutoRenewal = (tenure > 5) ? true : false;
		System.out.println("Is FDAccount need auto renewal? " + isAutoRenewal);

	}
	/* compareto method */
	@Override
	public int compareTo(FDAccount fAccount) {
		return this.accountHolderName.compareTo(fAccount.getAccountHolderName());
		
	}

}
