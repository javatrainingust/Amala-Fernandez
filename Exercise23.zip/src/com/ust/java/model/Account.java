/***
 * Account 
 * class is having private variables and setters and getters for private variables.
 * 30-09-2020
 * */
package com.ust.java.model;

/***
 * class is having private variables and setters and getters for private variables.
 * */

import com.ust.java.util.ICalculator;
import com.ust.java.util.IntrestCalculation;

public class Account {
	private int accountNo;
	protected String accountHolderName;
	protected float balance;
	/***
	 *Account class default constructor
	 * */
	public Account() {
		System.out.println("inside account default constructor");
	}
	/***
	 * Account class parameterised constructor
	 * */
	public Account(int accountNo, String accountHolderName,float balance) {
		super();
		this.accountNo = accountNo;
		this.accountHolderName = accountHolderName;
		this.balance=balance;
	//	System.out.println("inside account parameterised constructor");
	}
/*getter method for accountNo*/
	
	public int getAccountNo() {
		return accountNo;
	}
	/*setter method for accountNo*/
	
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	/*getter method for accountHolderName*/
	
	public String getAccountHolderName() {
		return accountHolderName;
	}
	/*setter method for accountHolderName*/
	
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	/*getter method for balance*/
	
	public float getBalance() {
		return balance;
	}
	/*setter method for balance*/
	
	public void setBalance(float balance) {
		this.balance = balance;
	}
	
	// IntrestCalculation interest=new IntrestCalculation();

	/* interestCalculation for calculating interest */
	
	
	public void interestCalculation(float amount, ICalculator interest) {
		float fdinterest = interest.calculateInterest(amount);
		System.out.println("Account interest" + fdinterest);
	}
	
	/* Hashcode method */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + accountNo;
		return result;
	}
	
	
	/* Equals method */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Account other = (Account) obj;
		if (accountNo != other.accountNo)
			return false;
		return true;
	}

	
}