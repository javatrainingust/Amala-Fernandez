/***
 * Renewable 
 * interface is for auto renewal checking overdraft.
 * 30-09-2020
 * */
package com.ust.java.model;

/***
 * interface is for auto renewal checking overdraft.
 * */
public interface Renewable {
	public void autoRenewal(int tenure);
}
