/*
 * SupplierInterface
 *SupplierInterface is a class for printing random numbers using lamda expression
 * 08-10-2020
 */

package com.training.java.functional;

import java.util.function.Supplier;
import java.util.Random; 

/*
 * SupplierInterface is a class for printing random numbers using lamda expression
 */
public class SupplierInterface {
	public static void main(String[] args) {
		
	Supplier<Integer> randomNumber = () -> new Random().nextInt(1000);
			
	System.out.println("Random Number1: "+randomNumber.get());
	System.out.println("Random Number2: "+randomNumber.get());
	System.out.println("Random Number3: "+randomNumber.get());
	System.out.println("Random Number4: "+randomNumber.get());

	}
	
}
