/*
 * ConsumerInterface
 * ConsumerInterface is a class for converting string in to uppercase using lamda expression
 * 08-10-2020
 */

package com.training.java.functional;

import java.util.function.Consumer;
import java.util.Locale; 

/*
 * ConsumerInterface is a class for converting string in to uppercase using lamda expression
 */
public class ConsumerInterface {

	public static void main(String[] args) {
		Consumer<String> StringInUpperCase=(X)->
        System.out.println("String in uppercase: "+X.toUpperCase());
		
        StringInUpperCase.accept("Amala");
	}

	

}
