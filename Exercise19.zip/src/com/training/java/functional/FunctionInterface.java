/*
 * FunctionInterface
 * FunctionInterface is a class for converting string in to uppercase using lamda expression
 * 08-10-2020
 */

package com.training.java.functional;

import java.util.function.Function;
/*
 * FunctionInterface is a class for converting string in to uppercase using lamda expression
 */
public class FunctionInterface {

	public static void main(String[] args) {
		
		Function<String,String> StringInUpperCase=(x)->{
       
		return	x.toUpperCase();
	};
	System.out.println("String in uppercase: "+StringInUpperCase.apply("Fernandez"));
}
}