package com.training.java.functional;

import java.util.function.Function;

public class FunctionInterface {

	public static void main(String[] args) {
		
		Function<String,String> StringInUpperCase=(x)->{
       
		return	x.toUpperCase();
	};
	System.out.println("String in uppercase: "+StringInUpperCase.apply("Fernandez"));
}
}