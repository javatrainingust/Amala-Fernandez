/*
 * PredicateInterface
 * PredicateInterface is a class for checking given value is greater than 50 using lamda expression
 * 08-10-2020
 */

package com.training.java.functional;

import java.util.function.Predicate;
/*
 * PredicateInterface is a class for checking given value is greater than 50 using lamda expression
 */
public class PredicateInterface {

	public static void main(String[] args) {
		
		Predicate<Integer> isGreater=(x)->{
			
			if(x>50){
				return true;
			}
			else
			{
				return false;
				
			}
		};
System.out.println("The value is greater than 50: "+isGreater.test(60));
	}

}
