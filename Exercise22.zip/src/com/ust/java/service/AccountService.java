package com.ust.java.service;

/**
 * In AccountService class invoke the respective methods 
 */


import com.ust.java.model.Account;
import com.ust.java.model.CurrentAccount;
import com.ust.java.model.FDAccount;
import com.ust.java.model.LoanAccount;
import com.ust.java.model.SBAccount;
import com.ust.java.service.*;
import com.ust.java.util.IntrestCalculation;

public class AccountService {

	public static void main(String args[]){
		
		
		
		
		
		SBAccount sb= new SBAccount();
		IntrestCalculation calculator=new IntrestCalculation();
        sb.interestCalculation(10000,calculator);
		FDAccount fd= new FDAccount();
		fd.autoRenewal(1);
		fd.interestCalculation(10000,calculator);
		CurrentAccount ca= new CurrentAccount();
		ca.CheckOverDraft(50001);
		
		LoanAccount la= new LoanAccount();
		la.CalculateEmi(200000);
	}

} 
