/***
 * CurrentAccountRetrievalDemo 
 * CurrentAccountRetrievalDemo is  class for Retrieving details
 * 06-10-2020
 * */
package com.training.java.service;
/***
 * CurrentAccountRetrievalDemo is  class for Retrieving details
 * */
public class CurrentAccountRetrievalDemo {

	public static void main(String[] args) {
	
CurrentAccountService currentAccountService=new CurrentAccountService();
		
currentAccountService.getAllCurrentAccounts();
		
		System.out.println("............................");
		
		currentAccountService.getCurrentAccountsByAccountNo(3001);

	}

}
