/***
 * CurrentAccountDeleteDemo 
 * CurrentAccountDeleteDemo is  class for deleting details
 * 06-10-2020
 * */

package com.training.java.service;
/***
 * CurrentAccountDeleteDemo is  class for deleting details
 * */
public class CurrentAccountDeleteDemo {

	public static void main(String[] args) {
		CurrentAccountService currentAccountService=new CurrentAccountService();
		currentAccountService.getAllCurrentAccounts();
		
		System.out.println("----------------------------------");
		currentAccountService.deleteCurrentAccount(3003);
		System.out.println("After Deletion");
		currentAccountService.getAllCurrentAccounts();

	}

}
