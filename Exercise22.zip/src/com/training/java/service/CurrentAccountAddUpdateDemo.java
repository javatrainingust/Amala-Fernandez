/***
 * CurrentAccountAddUpdateDemo 
 * CurrentAccountAddUpdateDemo is class for adding and updating CurrentAccount
 * 08-10-2020
 * */

package com.training.java.service;

import com.ust.java.model.CurrentAccount;
/***
 * CurrentAccountAddUpdateDemo is class for adding and updating CurrentAccount
 * */
public class CurrentAccountAddUpdateDemo {

	public static void main(String[] args) {
		CurrentAccountService currentAccountService=new CurrentAccountService();
		currentAccountService.addCurrentAccounts(new CurrentAccount(3000,"Amala",10000,5000));
		currentAccountService.addCurrentAccounts(new CurrentAccount(3001,"Mary",25000,15000));
		currentAccountService.addCurrentAccounts(new CurrentAccount(3001,"Mary",25000,15000));
		System.out.println("Printing all currentaccounts");
		currentAccountService.getAllCurrentAccounts();
		System.out.println("---------------------------------------------");
		currentAccountService.updateCurrentAccounts(new CurrentAccount(3001,"Mary",26000,15000));
		System.out.println("Printing all updated currentaccounts");
		currentAccountService.getAllCurrentAccounts();
	}

}
