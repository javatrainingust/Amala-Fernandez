/***
 * LoanAccountDaoServiceTest 
 * LoanAccountDaoServiceTest is  test class for LoanAccountDaoService
 * 07-10-2020
 * */
package com.training.java.service;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.ust.java.model.FDAccount;
import com.ust.java.model.LoanAccount;
/***
 *LoanAccountDaoServiceTest is  test class for LoanAccountDaoService
 * */
public class LoanAccountDaoServiceTest {

	

	LoanAccountDaoService loanAccountDaoService;

	/** Constructor for CurrentAccountServiceTest */

	public LoanAccountDaoServiceTest() {
		loanAccountDaoService = new LoanAccountDaoService();
	
		loanAccountDaoService.addLoanAccounts(new LoanAccount(4000,"Amala",1,12000,7000));
		loanAccountDaoService.addLoanAccounts(new LoanAccount(4001,"Mary",2,7000,90000));
			}
	
	
	/** Method  for add account  Success*/
				@Test
		public void testAddLoanAccountsSuccess() {
					
	assertTrue(loanAccountDaoService.addLoanAccounts(new LoanAccount(4002,"Amala",1,12000,7000)));

			}
				/** Method  for add account  failure*/
		@Test
		public 	void testAddLoanAccountsFailure() {
		assertFalse(loanAccountDaoService.addLoanAccounts(new LoanAccount(4002,"Amala",1,12000,7000)));
				
		}
		/** Method  for update account  Success*/
		@Test
		public void testUpdateLoanAccountsSuccess()
		 {
			assertTrue(loanAccountDaoService.updateLoanAccounts(new LoanAccount(4001,"Mary",2,12000,90000)));
		 }
	
/** Method  for update account  Failure*/
		@Test
		public void testUpdateLoanAccountsFailure()
		 {
			assertTrue(loanAccountDaoService.updateLoanAccounts(new LoanAccount(4008,"Mary",2,12000,90000)));
		 }
	
	/* for getting all accounts  sorted by names
	@Test
	public void testGetAllCurrentAccountsSortedByNames() {
		String expectedValue ="Fernandez";
		LoanAccountDaoService  loanAccountDaoService=new  LoanAccountDaoService();
		List<LoanAccount> loanAccountDaoServiceList=loanAccountDaoService.getAllCurrentAccountsSortedByNames();
		String actualValue=loanAccountDaoServiceList.get(2).getAccountHolderName();
		assertEquals(expectedValue,actualValue);
	}
	 for getting all accounts  sorted by Loanouitstanding amount
	@Test
	public void testGetAllCurrentAccountsSortedByOutStandingAmount() {
		float expectedValue =3000;
		LoanAccountDaoService  loanAccountDaoService=new  LoanAccountDaoService();
		List<LoanAccount> loanAccountDaoServiceList=loanAccountDaoService.getAllCurrentAccountsSortedByOutStandingAmount();
		float actualValue=loanAccountDaoServiceList.get(0).getLoanOutstanding();
		assertEquals(expectedValue,actualValue,0.0f);
	}
*/
}
