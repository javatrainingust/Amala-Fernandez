/***
 * LoanAccountRetrievalDemo 
 * LoanAccountRetrievalDemo is  class for Retrieving details
 * 06-10-2020
 * */
package com.training.java.service;

/***
 * LoanAccountRetrievalDemo is  class for Retrieving details
 * */
public class LoanAccountRetrievalDemo {

	public static void main(String[] args) {
		LoanAccountDaoService loanAccountService=new LoanAccountDaoService();
		
		loanAccountService.getAllLoanAccounts();
				
				System.out.println("............................");
				
				loanAccountService.getLoanAccountsByAccountNo(4003);

			}

	}


