/***
 * SBAccountDao 
 * SBAccountDao is an interface 
 * 06-10-2020
 * */

package com.training.java.dao;

import java.util.List;

import com.ust.java.model.FDAccount;
import com.ust.java.model.LoanAccount;
import com.ust.java.model.SBAccount;

/***
 * SBAccountDao is an interface 
 * */
public interface SBAccountDao {
	/* getAllSBAccounts method is for getting all the SBAccounts */
	public List<SBAccount> getAllSBAccounts();

	/* getSBAccountsByAccountNo method is for getting particular SBAccount */
	public SBAccount getSBAccountsByAccountNo(int accountNo);

	/* deleteSBAccount method is for deleting particular SBAccount */
	public void deleteSBAccount(int accountNo);
	/*  method is for adding  SB Accounts */
	
	  public boolean addSBAccounts(SBAccount sbAccount);
	  
	  /* method is for updating  SB Accounts details */
	  
		public boolean updateSBAccounts(SBAccount sbAccount);
}
