/***
 * SBAccountDaoImpl
 *  SBAccountDaoImpl is an implementation class for SBAccountDao
 * 06-10-2020
 * */
package com.training.java.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.ust.java.model.FDAccount;
import com.ust.java.model.LoanAccount;
import com.ust.java.model.SBAccount;

/***
 *  SBAccountDaoImpl is an implementation class for SBAccountDao
 * */
public class SBAccountDaoImpl implements SBAccountDao {

	List sbAccountList;
	Set sbAccountSet;
	/***
	 * SBAccountDaoImpl class constructor
	 * */
	public SBAccountDaoImpl() {
		sbAccountList = new ArrayList<SBAccount>();
		sbAccountSet=new HashSet<SBAccount>();
		
		SBAccount sbAccount1 = new SBAccount(2000, "Anu", 10000, 1);
		SBAccount sbAccount2 = new SBAccount(2001, "Anna", 20000, 2);
		SBAccount sbAccount3 = new SBAccount(2002, "Meenu", 30000, 3);
		SBAccount sbAccount4 = new SBAccount(2003, "Appu", 40000, 4);
		SBAccount sbAccount5 = new SBAccount(2004, "Nia", 50000, 5);

		sbAccountList.add(sbAccount1);
		sbAccountList.add(sbAccount2);
		sbAccountList.add(sbAccount3);
		sbAccountList.add(sbAccount4);
		sbAccountList.add(sbAccount5);

	}

	/* getAllSBAccounts method is for getting all the SBAccounts */
	@Override
	public List<SBAccount> getAllSBAccounts() {

		return sbAccountList;
	}

	/* getSBAccountsByAccountNo method is for getting particular SBAccount */
	@Override
	public SBAccount getSBAccountsByAccountNo(int accountNo) {
		SBAccount sAccount = null;
		Iterator<SBAccount> iterator = sbAccountList.iterator();
		while (iterator.hasNext()) {
			SBAccount sbaccount = iterator.next();
			if (sbaccount.getAccountNo() == accountNo) {

				sAccount = sbaccount;
			}
		}
		return sAccount;

	}

	/* deleteSBAccount method is for deleting particular SBAccount */
	@Override
	public void deleteSBAccount(int accountNo) {

		SBAccount sbAccount = null;
		Iterator<SBAccount> iterator = sbAccountList.iterator();
		while (iterator.hasNext()) {
			SBAccount sAccount = iterator.next();
			if (sAccount.getAccountNo() == accountNo) {

				sbAccount = sAccount;
			}

		}

		sbAccountList.remove(sbAccount);

	}
	
	/*  method is for adding  SB Accounts */
	
	@Override
	public boolean addSBAccounts(SBAccount sbAccount) {
boolean isAdded=sbAccountSet.add(sbAccount);
		
		if(isAdded){
			sbAccountList.add(sbAccount);
		}
		return isAdded;
	}
	
	 /* method is for updating  SB Accounts details */
	
	@Override
	public boolean updateSBAccounts(SBAccount sbAccount) {
		Iterator<SBAccount> iterator = sbAccountList.iterator();
		while(iterator.hasNext()){
			SBAccount sAccount=iterator.next();
              if(sAccount.getAccountNo()==sbAccount.getAccountNo()){
            	  
            	  sAccount.setAccountNo(sbAccount.getAccountNo());
            	  sAccount.setAccountHolderName(sbAccount.getAccountHolderName());
            	  sAccount.setBalance(sbAccount.getBalance());
            	  sAccount.setDuration(sbAccount.getDuration());
		
	}
		
	}
return true;
}}
