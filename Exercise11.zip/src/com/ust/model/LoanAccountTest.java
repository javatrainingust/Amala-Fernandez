package com.ust.model;

import static org.junit.Assert.*;

import org.junit.Test;

public class LoanAccountTest {

	@Test
	public void testCalculateEmi() {
		
		int expectedValue=83;
		LoanAccount loanAccount=new LoanAccount();
		loanAccount.CalculateEmi(1000);;
		
		int actualValue=loanAccount.getEmi();
		assertEquals(expectedValue,actualValue);
	}

}
