package com.ust.model;

import static org.junit.Assert.*;

import org.junit.Test;

public class FDAccountTest {

	@Test
	public void testAutoRenewal() {
		boolean expectedValue=true;
		FDAccount fdAccount=new FDAccount();
		fdAccount.autoRenewal(7);
		
		boolean actualValue=fdAccount.isAutoRenewal();
		assertEquals(expectedValue,actualValue);
	}

}
