package com.ust.model;

import static org.junit.Assert.*;

import org.junit.Test;

public class SBAccountTest {

	@Test
	public void testWithdrawMoney() {
		int expectedValue=40000;
		SBAccount sbAccount=new SBAccount();
		sbAccount.withdrawMoney(10000);;;
		
		int actualValue=(int) sbAccount.getBalance();
		assertEquals(expectedValue,actualValue);
	}

}
