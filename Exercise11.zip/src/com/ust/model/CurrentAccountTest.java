package com.ust.model;

import static org.junit.Assert.*;

import org.junit.Test;

public class CurrentAccountTest {

	@Test
	public void testCheckOverDraft() {
		
		String expectedValue= "Overdraft limit is 25000 as balance is above 50000";
		CurrentAccount ca= new CurrentAccount();
		String actualValue=ca.CheckOverDraft(90000);
		assertEquals(expectedValue,actualValue);
	}

}
