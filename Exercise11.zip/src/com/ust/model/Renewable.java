package com.ust.model;

/***
 * Renewable 
 * interface is for auto renewal checking overdraft.
 * 30-09-2020
 * */
public interface Renewable {
	public void autoRenewal(int tenure);
}
