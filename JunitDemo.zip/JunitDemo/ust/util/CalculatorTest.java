package com.ust.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class CalculatorTest {

	@Test
	public void testAdd() {
		
		int expectedValue=7;
		Calculator calculator=new Calculator();
		int actualValue=calculator.add(4, 3);
		assertEquals(expectedValue,actualValue);
	}

	@Test
	public void testSubtract() {
		int expectedValue=1;
		Calculator calculator=new Calculator();
		int actualValue=calculator.subtract(4, 3);
		assertEquals(expectedValue,actualValue);
	}

}
