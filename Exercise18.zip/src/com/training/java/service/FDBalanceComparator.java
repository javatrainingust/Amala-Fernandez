/***
 * CurrentOverDraftComparator 
 * CurrentOverDraftComparator is a  class for comparing using comparator
 * 07-10-2020
 * */

package com.training.java.service;

import java.util.Comparator;

import com.ust.java.model.FDAccount;
/*** 
 * CurrentOverDraftComparator is a  class for comparing using comparator
 * */
public class FDBalanceComparator implements Comparator<FDAccount>{

	@Override
	/*comparing two values*/
	public int compare(FDAccount one, FDAccount two) {
		
		return (int) (one.getBalance()-two.getBalance());
}
}