/***
 * SBAccountSortDemo 
 * SBAccountSortDemo is  class for displaying details
 * 07-10-2020
 * */
package com.training.java.service;
/***
 * SBAccountSortDemo 
 * SBAccountSortDemo is  class for displaying details
 * 07-10-2020
 * */
public class SBAccountSortDemo {

	public static void main(String[] args) {
		
		SBAccountService sbAccountService=new SBAccountService();
		sbAccountService.getAllSBAccounts();
			System.out.println("----------------------");
			System.out.println();
			System.out.println("displaying all FDAccounts after sorting");
			sbAccountService.getAllSBAccountsSortedByNames();
			System.out.println("----------------------");
			System.out.println();
			System.out.println("displaying all FDAccounts based on salary");
			sbAccountService.getAllSBAccountsSortedByBalance();
}

}
