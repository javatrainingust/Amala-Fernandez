/***
 * LoanAccountSortDemo 
 * LoanAccountSortDemo is  class for dispalying details
 * 07-10-2020
 * */
package com.training.java.service;
/***
 * LoanAccountSortDemo is  class for dispalying details
 * */
public class LoanAccountSortDemo {

	public static void main(String[] args) {
		LoanAccountDaoService loanAccountService=new LoanAccountDaoService();
		loanAccountService.getAllLoanAccounts();
			System.out.println("----------------------");
			System.out.println();
			System.out.println("displaying all FDAccounts after sorting");
			loanAccountService.getAllCurrentAccountsSortedByNames();
			System.out.println("----------------------");
			System.out.println();
			System.out.println("displaying all FDAccounts based on salary");
			loanAccountService.getAllCurrentAccountsSortedByOutStandingAmount();

	}

}
