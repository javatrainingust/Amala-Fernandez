/***
 * LoanAccountDaoImplTest
 *  LoanAccountDaoImplTest is a test class for LoanAccountDaoImpl
 *  06-10-2020
 * */

package com.training.java.dao;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.ust.java.model.LoanAccount;

/***
 * LoanAccountDaoImplTest is a test class for LoanAccountDaoImpl
 * */
public class LoanAccountDaoImplTest {
	List expectedList;

	/***
	 * LoanAccountDaoImplTest class constructor
	 * */
	public LoanAccountDaoImplTest() {
		expectedList = new ArrayList<LoanAccount>();
		LoanAccount loanAccount1=new LoanAccount(4000,"Amala",1,12000,7000);
		LoanAccount loanAccount2=new LoanAccount(4001,"Mary",2,7000,90000);
		LoanAccount loanAccount3=new LoanAccount(4002,"Carmel",2,6000,3000);
		LoanAccount loanAccount4=new LoanAccount(4003,"Fernandez",3,40000,50000);
		LoanAccount loanAccount5=new LoanAccount(4004,"Nia",4,1000,15200);

		expectedList.add(loanAccount1);
		expectedList.add(loanAccount2);
		expectedList.add(loanAccount3);
		expectedList.add(loanAccount4);
		expectedList.add(loanAccount5);
	}

	/* Test method for getAllLoanAccounts */
	@Test
	public void testGetAllLoanAccounts() {
		LoanAccountDaoImpl loanAccountDaoImpl = new LoanAccountDaoImpl();

		List actualList = loanAccountDaoImpl.getAllLoanAccounts();
		assertEquals(expectedList.size(), actualList.size());
	}

	/* Test method for getLoanAccountsByAccountNo */
	@Test
	public void testGetLoanAccountsByAccountNo() {
		String Expectedvalue = "Mary";
		LoanAccountDaoImpl loanAccountDaoImpl = new LoanAccountDaoImpl();
		LoanAccount actualvalue = loanAccountDaoImpl
				.getLoanAccountsByAccountNo(4001);
		assertEquals(Expectedvalue, actualvalue.getAccountHolderName());
	}

	/* Test method for deleteLoanAccount */
	@Test
	public void testDeleteLoanAccount() {
		LoanAccountDaoImpl loanAccountDaoImpl = new LoanAccountDaoImpl();
		loanAccountDaoImpl.deleteLoanAccount(4003);
		List actualList = loanAccountDaoImpl.getAllLoanAccounts();
		assertEquals(expectedList.size() - 1, actualList.size());
	}

}
