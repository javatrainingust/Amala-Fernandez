/***
 * FDAccountDao 
 * FDAccountDao is an interface
 *  06-10-2020
 * */
package com.training.java.dao;

import java.util.List;

import com.ust.java.model.FDAccount;
/*** 
 * FDAccountDao is an interface
 * */
public interface FDAccountDao {
	
	/* getAllFDAccounts method is for getting all the FDAccount */
	
public List<FDAccount> getAllFDAccounts();

/* getFDAccountsByAccountNo method is for getting particular FDAccount */

	public FDAccount getFDAccountsByAccountNo(int accountNo);
	
	/* deleteFDAccount method is for deleting particular FDAccount */
	
	public void deleteFDAccount(int accountNo);
	
	/*  method is for adding  FDAccounts */
	
  public boolean addFdAccounts(FDAccount fdAccount);
  
  /* method is for updating  FDAccounts details */
  
	public boolean updateFdAccounts(FDAccount fdAccount);
}
