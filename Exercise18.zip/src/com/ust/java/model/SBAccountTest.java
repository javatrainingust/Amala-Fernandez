/**
 *  SBAccountTest 
 *  SBAccountTest class is for testing SBAccoun class
 *  01-10-2020
 * */
package com.ust.java.model;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 *  SBAccountTest class is for testing SBAccoun class
 * */
public class SBAccountTest {

	/* Test method for testWithdrawMoney */
	@Test
	public void testWithdrawMoney() {
		int expectedValue=40000;
		SBAccount sbAccount=new SBAccount();
		sbAccount.withdrawMoney(10000);;;
		
		int actualValue=(int) sbAccount.getBalance();
		assertEquals(expectedValue,actualValue);
	}

}
