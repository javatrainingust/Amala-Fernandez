/***
 * SBAccountServiceTest 
 * SBAccountServiceTest is  class for displaying details
 * 07-10-2020
 * */
package com.training.service;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.ust.java.model.FDAccount;
import com.ust.java.model.LoanAccount;
import com.ust.java.model.SBAccount;
/***
 * SBAccountService 
 * SBAccountServiceTest is test class for SBAccountService
 * 06-10-2020
 * */
public class SBAccountServiceTest {
	

	SBAccountService sbAccountService;

	/** Constructor for CurrentAccountServiceTest */

	public SBAccountServiceTest() {
		sbAccountService = new SBAccountService();
	
		sbAccountService.addSBAccounts(new SBAccount(2000, "Anu", 10000, 1));
		sbAccountService.addSBAccounts(new SBAccount(2001, "Anna", 20000, 2));
			}
	
	
	/** Method  for add account  Success*/
				@Test
		public void testAddSbAccountsSuccess() {
					
	assertTrue(sbAccountService.addSBAccounts(new SBAccount(2002, "nia", 10000, 1)));

			}
				/** Method  for add account  failure*/
		@Test
		public 	void testAddSbAccountsFailure() {
		assertFalse(sbAccountService.addSBAccounts(new SBAccount(2000, "Anu", 10000, 1)));
				
		}
		/** Method  for update account  Success*/
		@Test
		public void testUpdateSbAccountsSuccess()
		 {
			assertTrue(sbAccountService.updateSBAccounts(new SBAccount(2001, "Anna", 40000, 2)));
		 }
	
          /** Method  for update account  Failure*/
		@Test
		public void testUpdateSbAccountsFailure()
		 {
			assertTrue(sbAccountService.updateSBAccounts(new SBAccount(2008, "Anna", 20000, 2)));
		 }
	
	
	
	/* for getting all accounts  sorted by names
	@Test
	public void testGetAllSBAccountsSortedByNames() {
		String expectedValue ="Anna";
		SBAccountService  sbAccountService=new  SBAccountService();
		List<SBAccount> sbAccountServiceList=sbAccountService.getAllSBAccountsSortedByNames();
		String actualValue=sbAccountServiceList.get(0).getAccountHolderName();
		assertEquals(expectedValue,actualValue);
	}
	 for getting all accounts  sorted by balance
	@Test
	public void testGetAllSBAccountsSortedByBalance() {
		float expectedValue =20000;
		SBAccountService  sbAccountService=new  SBAccountService();
		List<SBAccount> sbAccountServiceList=sbAccountService.getAllSBAccountsSortedByBalance();
		float actualValue=sbAccountServiceList.get(1).getBalance();
		assertEquals(expectedValue,actualValue,0.0f);
	}*/

}
