/***
 * CurrentAccountService 
 * CurrentAccountService is  class for displaying details
 * 06-10-2020
 * */

package com.training.service;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;









import com.training.java.dao.CurrentAccountDao;
import com.training.java.dao.CurrentAccountDaoImpl;
import com.ust.java.model.CurrentAccount;
import com.ust.java.model.FDAccount;

/***
 * CurrentAccountService is  class for displaying details
 * */
public class CurrentAccountService {
	CurrentAccountDao currentAccountDaoImpl;
	
	
	/***
	 * CurrentAccountService  class constructor
	 * */
	public CurrentAccountService(){
		
		currentAccountDaoImpl=new CurrentAccountDaoImpl();
	}
	
	/* for dispalying all the CurrentAccount */
	 
	public List<CurrentAccount> getAllCurrentAccounts() 
	{
		List currentAccountList=currentAccountDaoImpl.getAllCurrentAccounts();
		Iterator<CurrentAccount> iterator = currentAccountList.iterator();
		while(iterator.hasNext()){
			CurrentAccount currentAccount=iterator.next();
			
			System.out.println("Account No "+currentAccount.getAccountNo());
			System.out.println("Account Holder Name"+currentAccount.getAccountHolderName());
			System.out.println("balance "+currentAccount.getBalance());
		}
			return currentAccountList;
	}
	
	/*for displaying particular CurrentAccount */
	 
		public CurrentAccount getCurrentAccountsByAccountNo(int accountNo) 
		{
			CurrentAccount currentAccount=	currentAccountDaoImpl.getCurrentAccountsByAccountNo(accountNo);
			System.out.println("Account No "+currentAccount.getAccountNo());
			System.out.println("Account Holder Name"+currentAccount.getAccountHolderName());
			System.out.println("balance "+currentAccount.getBalance());
			return currentAccount;
		}
		
		/* for deleting particular CurrentAccount */
		
		public void deleteCurrentAccount(int accountNo) {
			
			currentAccountDaoImpl.deleteCurrentAccount(accountNo);	
		}
		
		/* for getting all accounts  sorted by names*/
		
		public List<CurrentAccount>	getAllCurrentAccountsSortedByNames(){
			
			
			List<CurrentAccount> currentAccountList = currentAccountDaoImpl.getAllCurrentAccounts();
			
			Collections.sort(currentAccountList);
			
			
			Iterator<CurrentAccount> iterator = currentAccountList.iterator();
			
			while(iterator.hasNext()){
				
				CurrentAccount currentAccount = iterator.next();
				
				System.out.println("Account No "+currentAccount.getAccountNo());
				System.out.println("Account Holder Name"+currentAccount.getAccountHolderName());
				System.out.println("balance "+currentAccount.getBalance());
				
				}			
			
			
			
			return currentAccountList;
		}
		
/* for getting all accounts  sorted by over draft limit*/
		
		public List<CurrentAccount>	getAllCurrentAccountsSortedByOverDraftLimit(){
			
			
			List<CurrentAccount> currentAccountList = currentAccountDaoImpl.getAllCurrentAccounts();
			
			Collections.sort(currentAccountList,new CurrentOverDraftComparator());
			
			
			Iterator<CurrentAccount> iterator = currentAccountList.iterator();
			
			while(iterator.hasNext()){
				
				CurrentAccount currentAccount = iterator.next();
				
				System.out.println("Account No "+currentAccount.getAccountNo());
				System.out.println("Account Holder Name"+currentAccount.getAccountHolderName());
				System.out.println("balance "+currentAccount.getBalance());
				System.out.println("over draft limit "+currentAccount.getOverDraftLimit());
				}			
			
			
			
			return currentAccountList;
		}
		
		/*  method is for adding  currentAccount */	
		
		public boolean addCurrentAccounts(CurrentAccount currentAccount) {
			boolean isAdded=currentAccountDaoImpl.addCurrentAccounts(currentAccount);
			
			if(!isAdded){
				System.out.println("current Account already exist");
				return false;
			}
			else{
			System.out.println("current Account successfully added");
			
			return true;
		}
			
		}

		/* method is for updating  FDAccounts details */

		public boolean updateCurrentAccounts(CurrentAccount currentAccount) {
			
			if(currentAccountDaoImpl.updateCurrentAccounts(currentAccount)){
				return  true;
			}
			else{
				System.out.println("current Account successfully added");
				
				return false;
	}
		}
}