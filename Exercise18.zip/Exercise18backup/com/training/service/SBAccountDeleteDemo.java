/***
 * SBAccountDeleteDemo 
 * SBAccountDeleteDemo is  class for deleting details
 * 06-10-2020
 * */
package com.training.service;
/***
 * SBAccountDeleteDemo is  class for deleting details
 * */
public class SBAccountDeleteDemo {

	public static void main(String[] args) {
		
SBAccountService sbAccountService=new SBAccountService();
		
		sbAccountService.getAllSBAccounts();
		
		System.out.println("............................");
		
		sbAccountService.deleteSBAccount(2001);
		System.out.println("After Deletion");
		sbAccountService.getAllSBAccounts();
	}

}
