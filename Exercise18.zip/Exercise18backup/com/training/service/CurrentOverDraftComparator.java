/***
 * CurrentOverDraftComparator 
 * CurrentOverDraftComparator is a  class for comparing using comparator
 * 07-10-2020
 * */

package com.training.service;

import java.util.Comparator;

import com.ust.java.model.CurrentAccount;
/***
* CurrentOverDraftComparator is a  class for comparing using comparator
 * */
public class CurrentOverDraftComparator implements Comparator<CurrentAccount> {

	@Override
	/*comparing two values*/
	public int compare(CurrentAccount one, CurrentAccount two) {
		// TODO Auto-generated method stub
		return (int) (one.getOverDraftLimit()-two.getOverDraftLimit());
	}

}
