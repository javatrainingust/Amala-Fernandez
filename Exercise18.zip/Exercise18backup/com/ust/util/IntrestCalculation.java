package com.ust.util;

/**
 * 
 * @author 100798
 *  IntrestCalculation 
 *  IntrestCalculation class is for calculating interest 
 *  30-09-2020
 * */

public class IntrestCalculation implements ICalculator {
	// float Rate=0.3f;
	float fdRate = 0.7f;
	float sbRate = 0.5f;
	float duration = 1;

	/* calculateInterest method for  calculating the interest */

	public float calculateInterest(float amount) {
		float interestamountfd = (amount * fdRate * duration) / 100;
		return interestamountfd;
	}

	/* calculateInterest method for  calculating the interest */

	public float calculateInterest(float amount, float duration) {
		float interestamountsb = (amount * sbRate * duration) / 100;
		return interestamountsb;
	}
}
