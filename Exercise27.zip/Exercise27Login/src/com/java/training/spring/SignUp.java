/*
 * SignUp
 * SignUp class is an entity class which includes details
 * 14-10-2020
 */
package com.java.training.spring;
/*
 * SignUp class is an entity class which includes details
 */
public class SignUp {

	private String name;
	private String userId;

	private String password;
	private String confirmPassowrd;
	
	/*
	 * getter method for name
	 */
	public String getName() {
		return name;
	}
	
	/*
	 * setter method for name
	 */
	
	public void setName(String name) {
		this.name = name;
	}
	
	/*
	 * getter method for userId
	 */
	
	public String getUserId() {
		return userId;
	}
	/*
	 * setter method for userId
	 */
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	/*
	 * getter method for password
	 */
	
	public String getPassword() {
		return password;
	}
	/*
	 * setter method for password
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	
	/*
	 * getter method for confirmpassword
	 */
	public String getConfirmPassowrd() {
		return confirmPassowrd;
	}
	/*
	 * setter method for confirmpassword
	 */
	public void setConfirmPassowrd(String confirmPassowrd) {
		this.confirmPassowrd = confirmPassowrd;
	}
	
	
	
}
