package com.ust.autorenewal.service;
/**
 * 
 *AutoRenewalService 
 *AutoRenewalService is class
 *30-09-2020
 */
import com.ust.java.model.FDAccount;
import com.ust.java.model.Renewable;

public class AutoRenewalService {

	public static void main(String args[]){
		Renewable ar=new FDAccount();
		ar.autoRenewal(7);
	}
	
}
