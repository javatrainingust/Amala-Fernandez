/***
 * FDAccountService 
 * FDAccountService is  class for displaying details
 * 06-10-2020
 * */
package com.training.java.service;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.java.dao.FDAccountDao;
import com.training.java.dao.FDAccountDaoImpl;
import com.ust.java.model.CurrentAccount;
import com.ust.java.model.FDAccount;
/***
 * FDAccountService is  class for displaying details
 * */

@Service
public class FDAccountService {

	@Autowired
	private FDAccountDao fdAccountdaoImpl;
	/***
	 * FDAccountService   class constructor
	 * */
	public FDAccountService(){
		
		
	}
	
	
	/* 
	 * for dispalying all the FDAccount */
	 
	public List<FDAccount> getAllFDAccounts() 
	{
	List fdAccountList=	fdAccountdaoImpl.getAllFDAccounts();
//	Iterator<FDAccount> iterator = fdAccountList.iterator();
//	while(iterator.hasNext()){
//		FDAccount FAccount=iterator.next();
//		
//		System.out.println("Account No "+FAccount.getAccountNo());
//		System.out.println("Account Holder Name"+FAccount.getAccountHolderName());
//		System.out.println("Tenure "+FAccount.getTenure());
//		System.out.println("Balance "+FAccount.getBalance());
//	}
		return fdAccountList;
	}
	
	/*
	 * for displaying particular FDAccount */
	
  public FDAccount getFDAccountsByAccountNo(int accountNo) {
	  FDAccount FAccount=	fdAccountdaoImpl.getFDAccountsByAccountNo(accountNo);
	  System.out.println("Account No "+FAccount.getAccountNo());
		System.out.println("Account Holder Name"+FAccount.getAccountHolderName());
		System.out.println("Tenure "+FAccount.getTenure());
		System.out.println("Balance "+FAccount.getBalance());
		return FAccount;
	}

  /* 
   * for deleting particular FDAccount */
  
	public void deleteFDAccount(int accountNo) 
	{
		
		fdAccountdaoImpl.deleteFDAccount(accountNo);
	}
	
	/* 
	 * for getting all accounts  sorted by names*/
	
public List<FDAccount>	getAllFDAccountsSortedByNames(){
		
		
		List<FDAccount> fAccountList = fdAccountdaoImpl.getAllFDAccounts();
		
		//Collections.sort(fAccountList);
		
		
		/* 
		 * Creating stream and sorting */
		
		Stream<FDAccount> fdAccountStream = fAccountList.stream();
		
		Stream<FDAccount> sortedStream = fdAccountStream.sorted();
		
		List sortedFdAccountList = sortedStream.collect(Collectors.toList());
		Iterator<FDAccount> iterator = sortedFdAccountList.iterator();
		
		while(iterator.hasNext()){
			
			FDAccount fAccount = iterator.next();
			
			System.out.println("Account No "+fAccount.getAccountNo());
			System.out.println("Account Holder Name"+fAccount.getAccountHolderName());
			System.out.println("Tenure "+fAccount.getTenure());
			System.out.println("Balance "+fAccount.getBalance());
			}			
		
		
		
		return fAccountList;
	}
/* 
 * for getting all accounts  sorted by balance
 */
public List<FDAccount>	getAllFDAccountsSortedByBalance(){
	
	
	List<FDAccount> fAccountList = fdAccountdaoImpl.getAllFDAccounts();
	
	//Collections.sort(fAccountList,new FDBalanceComparator());
	
	
	/*
	 *  Creating stream and sorting 
	 */
	Stream<FDAccount> fdAccountStream = fAccountList.stream();
	
	Stream<FDAccount> sortedStream = fdAccountStream.sorted(new FDBalanceComparator());
	
	List sortedFdAccountList = sortedStream.collect(Collectors.toList());
	
	Iterator<FDAccount> iterator = sortedFdAccountList.iterator();
	
	while(iterator.hasNext()){
		
		FDAccount fAccount = iterator.next();
		
		System.out.println("Account No "+fAccount.getAccountNo());
		System.out.println("Account Holder Name"+fAccount.getAccountHolderName());
		System.out.println("Tenure "+fAccount.getTenure());
		System.out.println("Balance "+fAccount.getBalance());
		}			
	
	
	
	return fAccountList;
}



/* 
 *  method is for adding  FDAccounts 
 */

public boolean addFdAccounts(FDAccount fdAccount) {
	boolean isAdded=fdAccountdaoImpl.addFdAccounts(fdAccount);
	
	if(!isAdded){
		System.out.println("FD Account already exist");
		return false;
	}
	else{
	System.out.println("FD Account successfully added");
	return true;
}
	
}

/*
 *  method is for updating  FDAccounts details 
 */

public boolean updateFdAccounts(FDAccount fdAccount) {
	
	if(fdAccountdaoImpl.updateFdAccounts(fdAccount))
	{
		return true;
		}
	
	else{
		return false;
	}
}}
