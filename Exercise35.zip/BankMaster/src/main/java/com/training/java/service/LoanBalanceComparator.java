/***
 * LoanBalanceComparator 
 * LoanBalanceComparator is a  class for comparing using comparator
 * 07-10-2020
 * */
package com.training.java.service;

import java.util.Comparator;

import com.ust.java.model.LoanAccount;
/***
 * LoanBalanceComparator is a  class for comparing using comparator
 * */
public class LoanBalanceComparator implements Comparator<LoanAccount> {

	
	/*
	 * comparing two values
	 */
	public int compare(LoanAccount one, LoanAccount two) {
		
		return (int) (one.getLoanOutstanding()-two.getLoanOutstanding());
	}

}
