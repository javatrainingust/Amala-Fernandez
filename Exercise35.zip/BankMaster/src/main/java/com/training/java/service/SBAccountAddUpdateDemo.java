/***
 * SBAccountAddUpdateDemo 
 * SBAccountAddUpdateDemo is class for adding and updating SBAccount
 * 08-10-2020
 * */
package com.training.java.service;

import com.ust.java.model.LoanAccount;
import com.ust.java.model.SBAccount;
/***
 * SBAccountAddUpdateDemo is class for adding and updating SBAccount
 * */
public class SBAccountAddUpdateDemo {
	/***
	 * main method
	 * */
	public static void main(String[] args) {
		SBAccountService SBAccountService=new SBAccountService();
		SBAccountService.addSBAccounts(new SBAccount(2000, "Anu", 10000, 1));
		SBAccountService.addSBAccounts(new SBAccount(2001, "Anna", 20000, 2));
		SBAccountService.addSBAccounts(new SBAccount(2001, "Anna", 20000, 2));
		
		System.out.println("Printing all SBaccount");	
		SBAccountService.getAllSBAccounts();
		
		System.out.println("---------------------------------------------");
		SBAccountService.updateSBAccounts(new SBAccount(2001, "Anna", 80000, 2));
		
		System.out.println("Printing all updated SBaccount");	
		SBAccountService.getAllSBAccounts();


	}

}
