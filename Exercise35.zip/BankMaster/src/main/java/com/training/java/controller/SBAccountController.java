/*
 * SBAccountController
 * SBAccountController is acontroller class having a method .
 * 15-10-2020
 */

package com.training.java.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.training.java.service.LoanAccountDaoService;
import com.training.java.service.SBAccountService;
import com.ust.java.model.LoanAccount;
import com.ust.java.model.SBAccount;

/*
 * SBAccountController is a controller class having a method .
 */
@Controller

public class SBAccountController {
	@Autowired
	private	SBAccountService sbAccountService;
	
	
	/*
	 * showForm is  a method to show LoanAccount form .
	 */	
	@RequestMapping("/showSbAccountForm")
	public String showForm(Model model){
		SBAccount sAccount=new SBAccount();
		model.addAttribute("key",sAccount);
		
		return "addSbAccount";
		
	}
	
	/*
	 * addLoanAccount is  a method to add currentAccount .
	 */	
	@RequestMapping("/addSbAccount")
	public String addSbAccount(@ModelAttribute("sbAccount") SBAccount sAccount) {
		
		
		sbAccountService.addSBAccounts(sAccount);
		
		return "redirect:/sb";
		
		
	}
	
	
	
	
	
	/*
	 * getAllSbAccounts is  a method which returns view name .
	 */	
	@RequestMapping("/sb")
	public String getAllSbAccounts(Model model){
		System.out.println("Inside SBAccountController ");
		List<SBAccount> sbAccountListList = sbAccountService.getAllSBAccounts();
		
		model.addAttribute("key",sbAccountListList );
		
		
		return "sbAccountList";
}
	/*
	 * getFdAccount is  a method to dispaly particular account details .
	 */	
	@RequestMapping("/viewSbAccount")
	public String getSbAccount(@RequestParam("accNo")String accNo,Model model) {
		
		
		SBAccount sbAccount = sbAccountService.getSBAccountsByAccountNo(Integer.parseInt(accNo));
		
		model.addAttribute("key", sbAccount);
		
		
		return "viewSbAccount";
		
}	

	/*
	 * deleteSbAccount is  a method to delete particular account details .
	 */	
	@RequestMapping("/deleteSbAccount")
	public String deleteSbAccount(@RequestParam("accNo")String accNo,Model model) {
		
		
		sbAccountService.deleteSBAccount(Integer.parseInt(accNo));
		
		
		
		
		return "redirect:/sb";
		
}	
	
	/*
	 * updateLoanAccount is  a method to update currentAccount .
	 */	
	@RequestMapping("/updateSbAccount")
	public String updateSbAccount(@ModelAttribute("sbAccount") SBAccount sAccount) {
		
		
		sbAccountService.updateSBAccounts(sAccount);
		
		return "redirect:/sb";
		
		
	}
}
