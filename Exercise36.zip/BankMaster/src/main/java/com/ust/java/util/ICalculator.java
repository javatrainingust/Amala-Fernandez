package com.ust.java.util;
/**
 * 
 * @author 100798
 *ICalculator 
 *ICalculator is an interface for calculating interest
 *30-09-2020
 */
public interface ICalculator {
	
	
	/*calculateInterest method calculate the interest and takes one argument that is amount*/
	public float calculateInterest(float amount);
	
	
	/*calculateInterest method calculate the interest and takes two arguments that is amount and duration*/
	public float calculateInterest(float amount,float duration);
}
