/*
 * PerformanceDemo
 * PerformanceDemo is a class and includes loading the definitions from the given XML file.
 * 13-10-2020
 */

package com.ust.training.java;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/*
 * PerformanceDemo is a class and includes loading the definitions from the given XML file.
 */
public class PerformanceDemo {
	/*
	 * Main method
	 */
	public static void main(String[] args) {
		
		// loading the definitions from the given XML file
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
		 
		InstrumentList instrumentList =  context.getBean("instrumentListOne",InstrumentList.class);
		instrumentList.perform();
	}

}
