/*
 * Saxophone
 * Saxophone is a class which implements Instrument
 * 13-10-2020
 */
package com.ust.training.java;
/*
 * Saxophone is a class which implements Instrument
 */
public class Saxophone implements Instrument {

	/*
	 * implementation method
	 */
	public void play() {
		System.out.println("Saxophone is playing");
		
	}

}
