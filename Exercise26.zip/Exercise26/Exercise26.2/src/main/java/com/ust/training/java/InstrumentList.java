/*
 * InstrumentaList
 * InstrumentaList is a class which implements Performer
 * 13-10-2020
 */
package com.ust.training.java;
/*
 * InstrumentaList is a class which implements Performer
 */
public class InstrumentList implements Performer {

	Saxophone saxophone;
	
	/*
	 * getter method for Saxophone
	 */
	
	public Saxophone getSaxophone() {
		return saxophone;
	}

	/*
	 * setter method for Saxophone
	 */

	public void setSaxophone(Saxophone saxophone) {
		this.saxophone = saxophone;
	}


	/*
	 * implementation method
	 */
	public void perform() {
		
		saxophone.play();
	}

}
