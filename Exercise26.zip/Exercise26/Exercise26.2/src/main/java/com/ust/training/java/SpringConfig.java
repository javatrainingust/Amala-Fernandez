/*
 * SpringConfig
 * SpringConfig is a class spring configuration
 * 13-10-2020
 */
package com.ust.training.java;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
/*
 * SpringConfig is a class spring configuration.
 */
@Configuration
public class SpringConfig {

	
	/*
	 * getInstrumentList() is a method that returns instrumentList
	 */
	@Bean(name = "instrumentListOne")
	public InstrumentList getInstrumentList() {
		
		System.out.println("inside getInstrumentList() method of SpringConfig class");
		
		InstrumentList instrumentList = new InstrumentList();
		instrumentList.setSaxophone(getSaxophone());
		return instrumentList;
	}
	
	
	/*
	 * getSaxophone() is a method that returns saxophone
	 */
	@Bean
	public Saxophone getSaxophone() {
		
		System.out.println("inside getSaxophone() method of SpringConfig class");
		
		Saxophone saxophone = new Saxophone();
		return saxophone;
	}
}
