/*
 * Organizer
 * Organizer is a class having a method sayGreetings.
 * 13-10-2020
 */

package com.ust.training.java;
/*
 * Organizer is a class having a method sayGreetings.
 */
public class Organizer {

	/*
	 * sayGreetings is a method,which displays greetings 
	 */
public void sayGreetings() {
	System.out.println("Welcome to the talent competion");
}
}
