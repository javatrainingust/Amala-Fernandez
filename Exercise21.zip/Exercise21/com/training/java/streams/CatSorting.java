/***
 * CatSorting
 * CatSorting class is for creating the arraylist and sorting in the string object using stream and comparable 
 * method 09-10-2020
 * */

package com.training.java.streams;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/***
 * CatSorting class is for creating the arraylist and sorting in the string object using stream and comparable 
 * */
public class CatSorting {

	public static void main(String[] args) {
		/* Creating Arraylist and adding values to it*/
		
		List<Cat> cats = new ArrayList<Cat>();
		cats.add(new Cat("Browny", 3));
		cats.add(new Cat("Kitty", 1));
		cats.add(new Cat("Pinky", 7));
		
		/* Creating Stream and sorting based on age*/
		
 Stream<Cat> catStream=cats.stream();
 Stream<Cat> SortedCatStream=catStream.sorted();
 SortedCatStream.forEach((e)->System.out.println(e));
	}

}
