/*
 * StreamOfOne
 * StreamOfOne is a class for double the elements and printing count of elements in the arraylist using streams 
 * 09-10-2020
 */

package com.training.java.streams;

import java.util.stream.Stream;
/*
 * StreamOfOne is a class for double the elements and printing count of elements in the arraylist using streams 
 */
public class StreamOfOne {

	public static void main(String[] args) {
		
		  /* Creating Stream*/
		
Stream<Integer> numbers=Stream.of(1,2,3,4,5,6,7,8,9);
long multiple=numbers.map((n)->(n*2)).filter((i)->(i>10)).count();

System.out.println(multiple);

	}
	
}
