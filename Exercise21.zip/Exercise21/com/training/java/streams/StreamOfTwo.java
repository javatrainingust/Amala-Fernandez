/*
 * StreamOfTwo
 * StreamOfTwo is a class forsorting in the strings using streams 
 * 09-10-2020
 */

package com.training.java.streams;

import java.util.stream.Stream;
/*
 * StreamOfTwo is a class forsorting in the strings using streams 
 */
public class StreamOfTwo {

	public static void main(String[] args) {
		
		/* Creating Stream*/
		
		Stream<String> studentNames=Stream.of("vinod","Suresh","Jane","Roshan").sorted();
		
		studentNames.forEach((e)->System.out.println(e));
		
	}

}
