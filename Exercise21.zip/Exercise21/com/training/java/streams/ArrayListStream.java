/*
 * ArrayListStream
 * ArrayListStream is a class for printing Number of elements in the arraylist using streams 
 * 09-10-2020
 */

package com.training.java.streams;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
/*
 * ArrayListStream is a class for printing Number of elements in the arraylist using streams 
 */
public class ArrayListStream {

	public static void main(String[] args) {
		
		/* Creating List*/
		
		List<String> names=new ArrayList<String>();
            names.add("VInod");
            names.add("Suresh");
            names.add("Jane");
            names.add("Roshan");
            
            /* Creating Stream*/ 
            
            Stream<String>  nameStream=names.stream();
            int noOfStrings=(int) nameStream.count();
            System.out.println("Number of Strings in the stream: "+noOfStrings);
	}

}
