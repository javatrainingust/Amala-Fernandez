/*
 * ArrayStream
 * ArrayStream is a class for printing Number of elements in the array using streams 
 * 09-10-2020
 */


package com.training.java.streams;

import java.util.Arrays;
import java.util.stream.Stream;

/*
 * ArrayStream is a class for printing Number of elements in the stream using streams 
 */
public class ArrayStream {

	public static void main(String[] args) {
		
		/* initialising  string*/
		
   String[] names={"vinod","Suresh","Jane","Roshan"};
   
   /* Creating Stream*/
   
   Stream<String>  arrayStream=Arrays.stream(names);
   
   int numberOfElements = (int) arrayStream.count();
   System.out.println("Number of elements in the stream: "+numberOfElements);
	}

}
