package com.training.service;
/***
 * SBAccountRetrievalDemo 
 * SBAccountRetrievalDemo is  class for Retrieving details
 * 06-10-2020
 * */
public class SBAccountRetrievalDemo {

	public static void main(String[] args) {
		SBAccountService sbAccountService=new SBAccountService();
		
		sbAccountService.getAllSBAccounts();
		
		System.out.println("............................");
		
		sbAccountService.getSBAccountsByAccountNo(2003);

	}

}
