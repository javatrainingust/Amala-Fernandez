package com.training.service;

import java.util.Iterator;
import java.util.List;





import com.training.dao.CurrentAccountDao;
import com.training.dao.CurrentAccountDaoImpl;
import com.ust.model.CurrentAccount;

/***
 * CurrentAccountService 
 * CurrentAccountService is  class for displaying details
 * 06-10-2020
 * */
public class CurrentAccountService {
	CurrentAccountDao currentAccountDaoImpl;
	
	public CurrentAccountService(){
		
		currentAccountDaoImpl=new CurrentAccountDaoImpl();
	}
	
	/* for dispalying all the CurrentAccount */
	 
	public List<CurrentAccount> getAllCurrentAccounts() 
	{
		List currentAccountList=currentAccountDaoImpl.getAllCurrentAccounts();
		Iterator<CurrentAccount> iterator = currentAccountList.iterator();
		while(iterator.hasNext()){
			CurrentAccount currentAccount=iterator.next();
			
			System.out.println("Account No "+currentAccount.getAccountNo());
			System.out.println("Account Holder Name"+currentAccount.getAccountHolderName());
			System.out.println("balance "+currentAccount.getBalance());
		}
			return currentAccountList;
	}
	
	/*for displaying particular CurrentAccount */
	 
		public CurrentAccount getCurrentAccountsByAccountNo(int accountNo) 
		{
			CurrentAccount currentAccount=	currentAccountDaoImpl.getCurrentAccountsByAccountNo(accountNo);
			System.out.println("Account No "+currentAccount.getAccountNo());
			System.out.println("Account Holder Name"+currentAccount.getAccountHolderName());
			System.out.println("balance "+currentAccount.getBalance());
			return currentAccount;
		}
		
		/* for deleting particular CurrentAccount */
		
		public void deleteCurrentAccount(int accountNo) {
			
			currentAccountDaoImpl.deleteCurrentAccount(accountNo);	
		}
	}

