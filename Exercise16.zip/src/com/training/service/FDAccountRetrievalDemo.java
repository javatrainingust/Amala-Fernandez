package com.training.service;

/***
 * FDAccountRetrievalDemo 
 * FDAccountRetrievalDemo is  class for Retrieving details
 * 06-10-2020
 * */
public class FDAccountRetrievalDemo {

	public static void main(String[] args) {
		FDAccountService fdAccountService=new FDAccountService();
		
		fdAccountService.getAllFDAccounts();
		
		System.out.println("----------------------------------");
		
		fdAccountService.getFDAccountsByAccountNo(1002);
	}

}
