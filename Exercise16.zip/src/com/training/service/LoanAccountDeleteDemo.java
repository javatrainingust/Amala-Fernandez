package com.training.service;
/***
 * LoanAccountDeleteDemo 
 * LoanAccountDeleteDemo is  class for deleting details
 * 06-10-2020
 * */
public class LoanAccountDeleteDemo {

	public static void main(String[] args) {
		LoanAccountDaoService loanAccountService=new LoanAccountDaoService();
		loanAccountService.getAllLoanAccounts();
		
		System.out.println("----------------------------------");
		loanAccountService.deleteLoanAccount(4001);;
		System.out.println("After Deletion");
		loanAccountService.getAllLoanAccounts();

	}

}
