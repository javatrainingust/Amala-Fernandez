package com.training.service;

import java.util.Iterator;
import java.util.List;

import com.training.dao.FDAccountDao;
import com.training.dao.FDAccountDaoImpl;
import com.ust.model.FDAccount;
/***
 * FDAccountService 
 * FDAccountService is  class for displaying details
 * 06-10-2020
 * */
public class FDAccountService {

	FDAccountDao fdAccountdaoImpl;
	
	public FDAccountService(){
		
		fdAccountdaoImpl=new FDAccountDaoImpl();
	}
	
	
	/* for dispalying all the FDAccount */
	 
	public List<FDAccount> getAllFDAccounts() 
	{
	List fdAccountList=	fdAccountdaoImpl.getAllFDAccounts();
	Iterator<FDAccount> iterator = fdAccountList.iterator();
	while(iterator.hasNext()){
		FDAccount FAccount=iterator.next();
		
		System.out.println("Account No "+FAccount.getAccountNo());
		System.out.println("Account Holder Name"+FAccount.getAccountHolderName());
		System.out.println("Tenure "+FAccount.getTenure());
	}
		return fdAccountList;
	}
	
	/*for displaying particular FDAccount */
	
  public FDAccount getFDAccountsByAccountNo(int accountNo) {
	  FDAccount FAccount=	fdAccountdaoImpl.getFDAccountsByAccountNo(accountNo);
	  System.out.println("Account No "+FAccount.getAccountNo());
		System.out.println("Account Holder Name"+FAccount.getAccountHolderName());
		System.out.println("Tenure "+FAccount.getTenure());
		return FAccount;
	}

  /* for deleting particular FDAccount */
  
	public void deleteFDAccount(int accountNo) 
	{
		
		fdAccountdaoImpl.deleteFDAccount(accountNo);
	}
}
