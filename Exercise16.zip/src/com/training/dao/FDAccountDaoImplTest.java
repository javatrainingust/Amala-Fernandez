package com.training.dao;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import com.ust.model.Account;
import com.ust.model.FDAccount;
import com.ust.util.IntrestCalculation;

/***
 * FDAccountDaoImplTest 
 * FDAccountDaoImplTest is a test class for FDAccountDaoImpl
 * 06-10-2020
 * */
public class FDAccountDaoImplTest {

	List EcpectedList;
	public FDAccountDaoImplTest(){
		EcpectedList=new ArrayList<FDAccount>();
		FDAccount fdAccount1=new FDAccount(1000,"Amala",1);
		FDAccount fdAccount2=new FDAccount(1001,"Mary",1);
		FDAccount fdAccount3=new FDAccount(1002,"Carmel",1);
		FDAccount fdAccount4=new FDAccount(1003,"Fernandez",1);
		FDAccount fdAccount5=new FDAccount(1004,"Nia",1);
		
		EcpectedList.add(fdAccount1);
		EcpectedList.add(fdAccount2);
		EcpectedList.add(fdAccount3);
		EcpectedList.add(fdAccount4);
		EcpectedList.add(fdAccount5);
	}
	
	/* Test method for getAllFDAccounts*/
	@Test
	public void testGetAllFDAccounts() {
		
		FDAccountDaoImpl fdAccountDaoImpl=new FDAccountDaoImpl();
		List actualValue= fdAccountDaoImpl.getAllFDAccounts();
		assertEquals(EcpectedList.size(),actualValue.size());
	}
	/* Test method for getFDAccountsByAccountNo*/
	@Test
	public void testGetFDAccountsByAccountNo() {
		String expectedvalue= "Carmel";
		FDAccountDaoImpl fdAccountDaoImpl=new FDAccountDaoImpl();
		 FDAccount actualValue= fdAccountDaoImpl.getFDAccountsByAccountNo(1002);	
		 assertEquals(expectedvalue,actualValue.getAccountHolderName());
	}
	/* Test method for deleteFDAccount*/
	@Test
	public void testDeleteFDAccount() {

		FDAccountDaoImpl fdAccountDaoImpl=new FDAccountDaoImpl();
		fdAccountDaoImpl.deleteFDAccount(1003);
		List actualValue= fdAccountDaoImpl.getAllFDAccounts();
		assertEquals(EcpectedList.size()-1,actualValue.size());
	}

}
