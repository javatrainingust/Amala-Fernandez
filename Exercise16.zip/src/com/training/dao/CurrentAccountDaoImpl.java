package com.training.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ust.model.CurrentAccount;

/***
 * CurrentAccountDaoImpl 
 * CurrentAccountDaoImpl is an implementation class for CurrentAccountDao
 * 06-10-2020
 * */
public class CurrentAccountDaoImpl implements CurrentAccountDao {

	
	
	
	List currentAccountList;
	public CurrentAccountDaoImpl()
	{
		currentAccountList=new ArrayList<CurrentAccount>();
		CurrentAccount currentAccount1=new CurrentAccount(3000,"Amala",10000);
		CurrentAccount currentAccount2=new CurrentAccount(3001,"Mary",11000);
		CurrentAccount currentAccount3=new CurrentAccount(3002,"Carmel",12000);
		CurrentAccount currentAccount4=new CurrentAccount(3003,"Fernandez",13000);
		CurrentAccount currentAccount5=new CurrentAccount(3004,"Nia",14000);
		
		currentAccountList.add(currentAccount1);
		currentAccountList.add(currentAccount2);
		currentAccountList.add(currentAccount3);
		currentAccountList.add(currentAccount4);
		currentAccountList.add(currentAccount5);
		
	}
	
	
	/* getAllCurrentAccounts method is for getting all the CurrentAccount */
	@Override
	public List<CurrentAccount> getAllCurrentAccounts() {
		
		return currentAccountList;
	}
	/* getCurrentAccountsByAccountNo method is for getting particular CurrentAccount */

	@Override
	public CurrentAccount getCurrentAccountsByAccountNo(int accountNo) {
		CurrentAccount currentAccounts=null;
		Iterator<CurrentAccount> iterator = currentAccountList.iterator();
		while(iterator.hasNext()){
			CurrentAccount cuAccount=iterator.next();
              if(cuAccount.getAccountNo()==accountNo){
				
            	  currentAccounts = cuAccount;
			}
			
			
		}
			
		
		return currentAccounts;
	}
	/* deleteCurrentAccount method is for deleting particular CurrentAccount */
	@Override
	public void deleteCurrentAccount(int accountNo) {
		CurrentAccount currentAccounts=null;
		Iterator<CurrentAccount> iterator = currentAccountList.iterator();
		while(iterator.hasNext()){
			CurrentAccount cuAccount=iterator.next();
              if(cuAccount.getAccountNo()==accountNo){
				
            	 currentAccounts = cuAccount;
            	  
			}
			
              
		
		
	}
		currentAccountList.remove(currentAccounts);
	}

}
