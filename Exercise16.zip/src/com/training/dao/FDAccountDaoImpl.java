package com.training.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ust.model.FDAccount;

/***
 * FDAccountDaoImpl 
 * FDAccountDaoImpl is an implementation class for FDAccountDao
 * 06-10-2020
 * */
public class FDAccountDaoImpl implements FDAccountDao  {

	List fdAccountList;
	public FDAccountDaoImpl()
	{
		fdAccountList=new ArrayList<FDAccount>();
		FDAccount fdAccount1=new FDAccount(1000,"Amala",1);
		FDAccount fdAccount2=new FDAccount(1001,"Mary",1);
		FDAccount fdAccount3=new FDAccount(1002,"Carmel",1);
		FDAccount fdAccount4=new FDAccount(1003,"Fernandez",1);
		FDAccount fdAccount5=new FDAccount(1004,"Nia",1);
		
		fdAccountList.add(fdAccount1);
		fdAccountList.add(fdAccount2);
		fdAccountList.add(fdAccount3);
		fdAccountList.add(fdAccount4);
		fdAccountList.add(fdAccount5);
		
	}
	
	
	/* getAllFDAccounts method is for getting all the FDAccount */
	@Override
	public List<FDAccount> getAllFDAccounts() {
		
		return fdAccountList;
	}
	/* getFDAccountsByAccountNo method is for getting particular FDAccount */
	@Override
	public FDAccount getFDAccountsByAccountNo(int accountNo) {
		
		
		FDAccount fdAccount=null;
		Iterator<FDAccount> iterator = fdAccountList.iterator();
		while(iterator.hasNext()){
			FDAccount FAccount=iterator.next();
              if(FAccount.getAccountNo()==accountNo){
				
				 fdAccount = FAccount;
			}
			
			
		}
			
		
		return fdAccount;
	}

	/* deleteFDAccount method is for deleting particular FDAccount */
	@Override
	public void deleteFDAccount(int accountNo) {
		FDAccount fdAccount=null;
		Iterator<FDAccount> iterator = fdAccountList.iterator();
		while(iterator.hasNext()){
			FDAccount FAccount=iterator.next();
              if(FAccount.getAccountNo()==accountNo){
            	  
            	  fdAccount=FAccount;
			}
              
			
		}
			
		fdAccountList.remove(fdAccount);
		
		
	}

	
	


}
