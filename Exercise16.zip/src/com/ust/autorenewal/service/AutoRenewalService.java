package com.ust.autorenewal.service;
/**
 * 
 *AutoRenewalService 
 *AutoRenewalService is class
 *30-09-2020
 */
import com.ust.model.FDAccount;
import com.ust.model.Renewable;

public class AutoRenewalService {

	public static void main(String args[]){
		Renewable ar=new FDAccount();
		ar.autoRenewal(7);
	}
	
}
