package com.ust.model;

/**
 * FDAccount 
 * FDAccount class includes FDAccount details
 * 30-09-2020
 */
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.ust.util.ICalculator;
import com.ust.util.IntrestCalculation;

public class FDAccount extends Account implements Renewable {

	private int tenure = 10;
	private boolean	isAutoRenewal;
	public String maturityDate = "28/09-2020";

	
	
	public int getTenure() {
		return tenure;
	}

	public FDAccount() {
		System.out.println("inside FDAccount default constructor");
	}

	public FDAccount(int accountNo,String accountHolderName,int tenure) {
		super(accountNo,accountHolderName);
		
		this.tenure = tenure;
	//	System.out.println("inside FDAccount parameterised constructor");
	}

	
	
	public boolean isAutoRenewal() {
		return isAutoRenewal;
	}



	Calendar calendar = Calendar.getInstance();

	// IntrestCalculation interest=new IntrestCalculation();

	/* interestCalculation for calculating interest and take two argument */

	public void interestCalculation(float amount, ICalculator interest) {
		float fdinterest = interest.calculateInterest(amount);
		System.out.println("FD interest" + fdinterest);
	}

	/* autoRenewal method for renewal of FD and take one argument */

	@Override
	public void autoRenewal(int tenure) {
		// TODO Auto-generated method stub

		 isAutoRenewal = (tenure > 5) ? true : false;
		System.out.println("Is FDAccount need auto renewal? " + isAutoRenewal);

	}

}
