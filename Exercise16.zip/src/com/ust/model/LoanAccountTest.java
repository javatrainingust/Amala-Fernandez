package com.ust.model;

import static org.junit.Assert.*;

import org.junit.Test;
/**
 * 
 *  LoanAccountTest 
 *  LoanAccountTest class is for testing LoanAccount class
 *  01-10-2020
 * */
public class LoanAccountTest {
	
	/* calculateInterest method for  testCalculateEmi */
	@Test
	public void testCalculateEmi() {
		
		int expectedValue=83;
		LoanAccount loanAccount=new LoanAccount();
		loanAccount.CalculateEmi(1000);;
		
		int actualValue=loanAccount.getEmi();
		assertEquals(expectedValue,actualValue);
	}

}
