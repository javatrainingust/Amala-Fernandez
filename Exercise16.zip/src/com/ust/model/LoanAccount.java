package com.ust.model;

/**
 * LoanAccount 
 * LoanAccount class includes LoanAccount details
 *  30-09-2020
 */
public class LoanAccount extends Account {

	 int tenure;
	float loanOutstanding;
	private int emi;
	
	
	public int getEmi() {
		return emi;
	}



	public LoanAccount() {
		System.out.println("inside LoanAccount default constructor");
	}

	public LoanAccount(int accountNo, String accountHolderName,int tenure) {
		super(accountNo,accountHolderName);
		this.tenure = tenure;
		System.out.println("inside LoanAccount parameterised constructor");

	}

	/* CalculateEmi method for calculating EMI */

	public int getTenure() {
		return tenure;
	}



	public void CalculateEmi(int loanTaken) {
		 emi = loanTaken / tenure;
		loanOutstanding = loanTaken - emi;
		System.out.println("Emi " + loanTaken + " is: " + emi);
		System.out.println("Loan Outstanding Amount: " + loanOutstanding);
	}

}
