/*
 * AboutMeController
 * AboutMeController is a controller class having a method getMyHobbies().
 * 14-10-2020
 */

package com.ust.java.spring;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/*
 * AboutMeController is a controller class having a method getMyHobbies().
 */

@Controller
public class AboutMeController {
	
	/*
	 * getMyHobbies is a method which return a string
	 */
	
	@RequestMapping("/hobbies")
	public String getMyHobbies() {
		return "hobbies";
	}
}
