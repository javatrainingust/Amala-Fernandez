package com.ust.collection;
/***
 * Cat 
 * Cat class is a entity class having variables, tostring and compareto method
 * 05-10-2020
 * */
public class Cat implements Comparable<Cat>{

		
			private String name;
			private Integer age;

			
			
			
			public String getName() {
				return name;
			}

			public Integer getAge() {
				return age;
			}

			/* no argument constructor */
			public Cat() {

			}

			/* parameterized constructor */
			public Cat(String name, int age) {
				super();
				this.name = name;
				this.age = age;
			}

			@Override
			public String toString() {
				return "Cat [name=" + name + ", age=" + age + "]";
			}

			/* method for comparing  age of the cat */
			@Override
			public int compareTo(Cat c) {

				return age.compareTo(c.age);
			}

		} 
		 

