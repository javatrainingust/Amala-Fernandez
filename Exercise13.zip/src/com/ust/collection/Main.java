package com.ust.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/***
 * Main
 * Main class is for creating the arraylist and and iterating through array list and displaying it
 * method 05-10-2020
 * */
public class Main {

	public static void main(String[] args) {
		
		/*Creating arraylist*/
		List<Cat> cats = new ArrayList<Cat>();
		cats.add(new Cat("Browny", 3));
		cats.add(new Cat("Kitty", 1));
		cats.add(new Cat("Pinky", 7));

		System.out.println("Before sorting");
		
		/*For iterating through the arraylist*/
		Iterator<Cat> catiterator = cats.iterator();
		while (catiterator.hasNext()) {

			Cat cat = catiterator.next();

			System.out.println(cat);
		}
		System.out.println();
		System.out.println("Cats sorted by age");
		Collections.sort(cats);
		
		/*For iterating through the arraylist*/
		
		Iterator<Cat> catiterator1 = cats.iterator();
		while (catiterator1.hasNext()) {

			Cat cat = catiterator1.next();
			System.out.println(cat);
		}

	}

}
