package com.ust.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/***
 * StudentList StudentList class is for dispalying students in sorted order
 * 05-10-2020
 * */
public class StudentList {

	public static void main(String[] args) {

		/* Creating arraylist */
		List<String> students = new ArrayList<String>();

		students.add("Vivek");
		students.add("Vijay");
		students.add("Ajith");
		students.add("Surya");

		/* For iterating through the arraylist */

		for (String studentsList : students) {

			System.out.println(studentsList);
		}

		System.out.println("After sorting the arraylist");
		System.out.println();

		/* For sorting the arraylist */
		Collections.sort(students);

		/* For iterating through the arraylist */
		for (String studentsList : students) {

			System.out.println(studentsList);
		}
	}
}
