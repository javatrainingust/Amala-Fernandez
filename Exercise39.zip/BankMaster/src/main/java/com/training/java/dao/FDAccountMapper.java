/***
 * FDAccountMapper 
 * FDAccountMapper is  class which implements RowMapper
 * 23-10-2020
 * */

package com.training.java.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ust.java.model.FDAccount;

/***
 * FDAccountMapper is  class which implements RowMapper
 * 
 * */
public class FDAccountMapper implements RowMapper<FDAccount> {

	/***
	 * FDAccountMapper is  a method which has parameters ResultSet and rowNum.
	 * 
	 * */
	public FDAccount mapRow(ResultSet rs, int rowNum) throws SQLException {
		FDAccount fdAccount=new FDAccount();
		fdAccount.setAccountNo(rs.getInt("accountNo"));
		fdAccount.setAccountHolderName(rs.getString("accountHolderName"));
		fdAccount.setBalance(rs.getFloat("balance"));
		fdAccount.setTenure(rs.getInt("tenure"));
		return fdAccount;
	}

}
