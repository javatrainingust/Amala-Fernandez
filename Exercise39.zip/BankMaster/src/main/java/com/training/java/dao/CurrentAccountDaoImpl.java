/***
 * CurrentAccountDaoImpl 
 * CurrentAccountDaoImpl is an implementation class for CurrentAccountDao
 * 06-10-2020
 * */

package com.training.java.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Repository;

import com.ust.java.model.CurrentAccount;
import com.ust.java.model.FDAccount;

/***
 * CurrentAccountDaoImpl is an implementation class for CurrentAccountDao
 * */

public class CurrentAccountDaoImpl implements CurrentAccountDao {

	
	
	
	List currentAccountList;
	Set currentAccountSet;
	
	/***
	 * CurrentAccountDaoImpl class constructor
	 * */
	public CurrentAccountDaoImpl()
	{
		currentAccountList=new ArrayList<CurrentAccount>();
		currentAccountSet=new HashSet<CurrentAccount>();
		
		CurrentAccount currentAccount1=new CurrentAccount(3000,"Amala",10000,5000);
		CurrentAccount currentAccount2=new CurrentAccount(3001,"Mary",25000,15000);
		CurrentAccount currentAccount3=new CurrentAccount(3002,"Carmel",12000,5000);
		CurrentAccount currentAccount4=new CurrentAccount(3003,"Fernandez",50000,25000);
		CurrentAccount currentAccount5=new CurrentAccount(3004,"Nia",140000,25000);
		
		currentAccountList.add(currentAccount1);
		currentAccountList.add(currentAccount2);
		currentAccountList.add(currentAccount3);
		currentAccountList.add(currentAccount4);
		currentAccountList.add(currentAccount5);
		
	}
	
	
	/*
	 *  getAllCurrentAccounts method is for getting all the CurrentAccount 
	 */
	public List<CurrentAccount> getAllCurrentAccounts() {
		System.out.println("Inside CurrentAccountDAOimpl getAllCurrentAccounts");
		return currentAccountList;
	}
	/* 
	 * getCurrentAccountsByAccountNo method is for getting particular CurrentAccount 
	 */

	public CurrentAccount getCurrentAccountsByAccountNo(int accountNo) {
		CurrentAccount currentAccounts=null;
		Iterator<CurrentAccount> iterator = currentAccountList.iterator();
		while(iterator.hasNext()){
			CurrentAccount cuAccount=iterator.next();
              if(cuAccount.getAccountNo()==accountNo){
				
            	  currentAccounts = cuAccount;
			}
			
			
		}
			
		
		return currentAccounts;
	}
	/* 
	 * deleteCurrentAccount method is for deleting particular CurrentAccount 
	 */
	public void deleteCurrentAccount(int accountNo) {
		CurrentAccount currentAccounts=null;
		Iterator<CurrentAccount> iterator = currentAccountList.iterator();
		while(iterator.hasNext()){
			CurrentAccount cuAccount=iterator.next();
              if(cuAccount.getAccountNo()==accountNo){
				
            	 currentAccounts = cuAccount;
            	  
			}
	}
		currentAccountList.remove(currentAccounts);
	}

	/* 
	 *  method is for adding  Current Accounts 
	 */
	public boolean addCurrentAccounts(CurrentAccount currentAccount) {
boolean isAdded=currentAccountSet.add(currentAccount);
		
		if(isAdded){
			currentAccountList.add(currentAccount);
		}
		return isAdded;
	}

	/* 
	 * method is for updating  Current Accounts details 
	 */
	public boolean updateCurrentAccounts(CurrentAccount currentAccount) {
		Iterator<CurrentAccount> iterator = currentAccountList.iterator();
		while(iterator.hasNext()){
			CurrentAccount cAccount=iterator.next();
              if(cAccount.getAccountNo()==currentAccount.getAccountNo()){
            	  
            	  cAccount.setAccountNo(currentAccount.getAccountNo());
            	  cAccount.setAccountHolderName(currentAccount.getAccountHolderName());
            	  cAccount.setBalance(currentAccount.getBalance());
            	  cAccount.setOverDraftLimit(currentAccount.getOverDraftLimit());
		
	}

              }
		return true;
		}
}
