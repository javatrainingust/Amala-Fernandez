/***
 * SBBalanceComparator 
 * SBBalanceComparator is a  class for comparing using comparator
 * 07-10-2020
 * */
package com.training.java.service;

import java.util.Comparator;

import com.ust.java.model.FDAccount;
import com.ust.java.model.SBAccount;
/***
 * SBBalanceComparator is a  class for comparing using comparator
 * */
public class SBBalanceComparator implements  Comparator<SBAccount>{
	
	/*
	 * comparing two values
	 */
	public int compare(SBAccount one, SBAccount two) {
		
		return (int) (one.getBalance()-two.getBalance());
}
}