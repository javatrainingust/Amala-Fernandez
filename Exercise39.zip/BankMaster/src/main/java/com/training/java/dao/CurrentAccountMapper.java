/***
 * CurrentAccountMapper 
 * CurrentAccountMapper is  class which implements RowMapper
 * 23-10-2020
 * */
package com.training.java.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ust.java.model.CurrentAccount;

/***
 * CurrentAccountMapper is  class which implements RowMapper
 * */
public class CurrentAccountMapper implements RowMapper<CurrentAccount>{
	/***
	 * CurrentAccount is  a method which has parameters ResultSet and rowNum.
	 * 
	 * */
	public CurrentAccount mapRow(ResultSet rs, int rowNum) throws SQLException {
		CurrentAccount currentAccount=new CurrentAccount();
		currentAccount.setAccountNo(rs.getInt("accountNo"));
		currentAccount.setAccountHolderName(rs.getString("accountHolderName"));
		currentAccount.setBalance(rs.getFloat("balance"));
		currentAccount.setOverDraftLimit(rs.getFloat("OverDraftLimit"));
		
		return currentAccount;
	}

}
