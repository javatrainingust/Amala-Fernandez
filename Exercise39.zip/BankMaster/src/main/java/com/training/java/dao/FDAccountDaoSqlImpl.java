/***
 * FDAccountDaoSqlImpl 
 * FDAccountDaoSqlImpl is an implementation class for FDAccountDao
 * 23-10-2020
 * */
package com.training.java.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;


import com.ust.java.model.FDAccount;
/***
 * FDAccountDaoSqlImpl is an implementation class for FDAccountDao
 * */
@Repository
public class FDAccountDaoSqlImpl implements FDAccountDao {

	private DataSource dataSource;
	private JdbcTemplate jdbcTemplateObject;
	
	
	/***
	 * setDataSource is a setter method for datasource
	 * 
	 * */
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		jdbcTemplateObject = new JdbcTemplate(dataSource);
	}
	
	/* 
	 * getAllFDAccounts method is for getting all the FDAccount 
	 */
	
	public List<FDAccount> getAllFDAccounts() {
		String sql="select * from fdaccount";
		List<FDAccount> fAccounts=jdbcTemplateObject.query(sql,new FDAccountMapper());
		
		return fAccounts;
	}

	/* 
	 * getFDAccountsByAccountNo method is for getting particular FDAccount 
	 */
	
	public FDAccount getFDAccountsByAccountNo(int accountNo) {
		String sql="select * from fdaccount where accountNo=?";
		FDAccount fAccounts=jdbcTemplateObject.queryForObject(sql, new Object[] {accountNo}, new FDAccountMapper());
		
		return fAccounts;
	}

	/* 
	 * deleteFDAccount method is for deleting particular FDAccount 
	 */
	
	public void deleteFDAccount(int accountNo) {
		String query="delete from fdaccount where accountNo='"+accountNo+"' ";  
		jdbcTemplateObject.update(query); 
	}


	/* 
	 *  method is for adding  FDAccounts
	 */
	
	public boolean addFdAccounts(FDAccount fdAccount) {
		String sql="insert into fdaccount(accountNo,accountHolderName,balance,tenure)values(?,?,?,?)";
		jdbcTemplateObject.update(sql, new Object[] {fdAccount.getAccountNo(),fdAccount.getAccountHolderName(),fdAccount.getBalance(),fdAccount.getTenure()});
		return true;
	}

	 /* 
	  * method is for updating  FDAccounts details 
	  */
	
	public boolean updateFdAccounts(FDAccount fdAccount) {
		String query="update fdaccount set  accountNo='"+fdAccount.getAccountNo()+"',accountHolderName='"+fdAccount.getAccountHolderName()+"',balance='"+fdAccount.getBalance()+"',tenure='"+fdAccount.getTenure()+"' where accountNo='"+fdAccount.getAccountNo()+"' ";  
	    jdbcTemplateObject.update(query);  

		return false;
	}

}
