/***
 * FDAccountRetrievalDemo 
 * FDAccountRetrievalDemo is  class for Retrieving details
 * 06-10-2020
 * */
package com.training.java.service;

/***
 * FDAccountRetrievalDemo is  class for Retrieving details
 * */
public class FDAccountRetrievalDemo {
	/***
	 * main method
	 * */
	public static void main(String[] args) {
		FDAccountService fdAccountService=new FDAccountService();
		
		fdAccountService.getAllFDAccounts();
		
		System.out.println("----------------------------------");
		
		fdAccountService.getFDAccountsByAccountNo(1002);
	}

}
