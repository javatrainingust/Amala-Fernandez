/*
 * Saxophone
 * Saxophone is a class which implements Instrument
 * 12-10-2020
 */
package com.ust.training.model;

import com.ust.training.util.Instrument;
/*
 * Saxophone is a class which implements Performer
 */
public class Saxophone implements Instrument {
	
	/*
	 * implementation method
	 */

	public void play() {
		System.out.println("saxaphone is playing");
		
	}

}
