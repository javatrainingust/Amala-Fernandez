/*
 * Instrument
 * Instrument is an interface having a method play.
 * 12-10-2020
 */
package com.ust.training.util;
/*
 * Instrument is an interface having a method play.
 */
public interface Instrument {
	/*
	 * Instrument is an interface having a method play.
	 */	
public void play();
}
