/*
 * Guitar
 * Guitar is a class which implements Instrument
 * 12-10-2020
 */

package com.ust.training.model;

import com.ust.training.util.Instrument;
/*
 * Guitar is a class which implements Instrument
 */
public class Guitar implements Instrument {

	/*
	 * implementation method
	 */
	public void play() {
		
		System.out.println("Guitar is playing");
		
	}

}
