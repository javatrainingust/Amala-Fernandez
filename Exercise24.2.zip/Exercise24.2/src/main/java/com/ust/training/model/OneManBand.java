/*
 * OneManBand
 * OneManBand is a class which implements Performer
 * 12-10-2020
 */
package com.ust.training.model;

import java.util.ArrayList;
import java.util.List;

import com.ust.training.util.Instrument;
import com.ust.training.util.Performer;

/*
 * OneManBand is a class which implements Performer
 */

public class OneManBand implements Performer{

	List<Instrument> instruments;
	/*
	 * getter for instruments
	 */
	
	public List<Instrument> getInstruments() {
		return instruments;
	}

	/*
	 * setter for instruments
	 */
	public void setInstruments(List<Instrument> instruments) {
		this.instruments = instruments;
	}

	/*
	 * perform method is an implementation method
	 */
	public void perform() {
		
		/*for each for iterating through list*/
		
		for (Instrument instrument : instruments) {
			
			instrument.play();
		}
		
	}

}
