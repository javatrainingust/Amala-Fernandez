package com.ust.model;
/***
 * CurrentAccount 
 * class checking overdraft.
 * 30-09-2020
 * */
public class CurrentAccount extends Account {
    
    float OverDraftLimit;
    private float balance=50000;
    
    public CurrentAccount(){
    	System.out.println("inside CurrentAccount default constructor");
    }  
    
    
    public CurrentAccount(float balance) {
		super();
		this.balance = balance;
		
		System.out.println("inside CurrentAccount parameterised constructor");
	}


  /* CheckOverDraft is for checking overdraft amount */
    
	public void CheckOverDraft()
    {
    /*condition check */
    if(balance>=50000)
    {
          System.out.println("Overdraft limit is 25000 as balance is above 50000");
    }
    
    else if(balance >25000 && balance <50000)
          System.out.println("Overdraft limit is 15000 as balance is between 25000 and 50000");
    
    else
          System.out.println("Overdraft limit is 5000 as balance is below 25000");

    }
}

