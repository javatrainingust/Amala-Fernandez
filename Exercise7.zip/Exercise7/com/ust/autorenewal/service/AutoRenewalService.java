package com.ust.autorenewal.service;

import com.ust.model.FDAccount;
import com.ust.model.Renewable;

public class AutoRenewalService {

	public static void main(String args[]){
		Renewable ar=new FDAccount();
		ar.autoRenewal(7);
	}
	
}
