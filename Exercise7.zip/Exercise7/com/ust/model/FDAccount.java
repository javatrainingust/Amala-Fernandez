package com.ust.model;
/**
 * FDAccount class extends Account class and implements Renewable class.Which is having a two methods, interestCalculation method for calculating interest and autoRenewal method for renewal of FD 
 */
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;



import com.ust.util.ICalculator;
import com.ust.util.IntrestCalculation;

public class FDAccount extends Account implements Renewable {

    public int tenure=10;
  public  String maturityDate="28/09-2020";
   
   
   
   
    Calendar calendar = Calendar.getInstance();  
    //IntrestCalculation interest=new IntrestCalculation();
   
    /*interestCalculation for calculating interest and take two argument */ 
public void interestCalculation(float amount,ICalculator interest){
float fdinterest=interest.calculateInterest( amount);
System.out.println(fdinterest);
}

/*autoRenewal method for renewal of FD  and take one argument */

@Override
public void autoRenewal(int tenure) {
// TODO Auto-generated method stub

boolean isAutoRenewal = (tenure>5)?true:false;
     System.out.println("Is FDAccount need auto renewal? " +isAutoRenewal);

}

}

