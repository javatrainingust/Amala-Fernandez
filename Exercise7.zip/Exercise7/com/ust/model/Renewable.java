package com.ust.model;

public interface Renewable {
	public void autoRenewal(int tenure);
}
