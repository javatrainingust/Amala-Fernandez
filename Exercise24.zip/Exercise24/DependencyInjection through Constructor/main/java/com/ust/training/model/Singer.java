/*
 * Singer
 * Singer is a class ,which implements Performer.
 * 12-10-2020
 */
package com.ust.training.model;

import com.ust.training.util.Performer;
/*
 * Singer is a class ,which implements Performer.
 */
public class Singer implements Performer {

	private String song;
	
	/*
	 * Singer is a class constructor
	 */
	public Singer(String song) {
		this.song=song;
	}
	
	/*
	 * perform method will provide the performance details
	 */
	public void perform() {
		
		System.out.println("Next song is "+song);
	}

}
