/*
 * PerformanceDemo
 * PerformanceDemo main class which is l.oading the definitions from the given XML file
 * 12-10-2020
 */
package com.ust.training.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ust.training.model.Singer;

/*
 * PerformanceDemo main class which is l.oading the definitions from the given XML file
 */
public class PerformanceDemo {

	/*
	 * Main method
	 */
	
	public static void main(String[] args) {
		
		// loading the definitions from the given XML file
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		 
		Singer singers =  context.getBean("singer",Singer.class);
		singers.perform();
	}

}
