
/*
 * SpringDemo
 * SpringDemo is a class and includes loading the definitions from the given XML file.
 * 12-10-2020
 */

package com.ust.training.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;
/*
 * SpringDemo is a class and includes loading the definitions from the given XML file.
 */
public class SpringDemo {

	/*
	 * Main method
	 */
	
	public static void main(String[] args) {
		
		// loading the definitions from the given XML file
				ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
				 
				Organizer organizer =  context.getBean("competitionOrganiser",Organizer.class);
				organizer.sayGreetings();
				
	}


	}


